execute store result score @s bse.rand run random value 25..30
scoreboard players operation @s bse.target = @s bse.rand
