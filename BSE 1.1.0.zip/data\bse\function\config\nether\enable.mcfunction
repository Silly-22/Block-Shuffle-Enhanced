execute if entity @s[gamemode=spectator] run return run function bse:msg_settings_spectator
execute if score #game bse.status matches 1.. run return run function bse:msg_settings_ingame
scoreboard players set #nether_enabled bse.config 1
execute if score #language bse.language matches 0 run tellraw @s [{"text":"[BSE] Nether blocks enabled","color":"red"}]
execute if score #language bse.language matches 1 run tellraw @s [{"text":"[BSE] Bloques del Nether habilitados","color":"red"}]
function bse:setup_blocks
