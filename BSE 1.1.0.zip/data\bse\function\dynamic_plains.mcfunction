# Plains / meadow: grass, oak log + oak variants, pumpkin
execute store result score @s bse.rand run random value 1..6
execute if score @s bse.rand matches 1 run scoreboard players set @s bse.target 6
execute if score @s bse.rand matches 2 run scoreboard players set @s bse.target 4
execute if score @s bse.rand matches 3 run scoreboard players set @s bse.target 39
execute if score @s bse.rand matches 4 run scoreboard players set @s bse.target 43
execute if score @s bse.rand matches 5 run scoreboard players set @s bse.target 44
execute if score @s bse.rand matches 6 run scoreboard players set @s bse.target 45
