execute if entity @s[gamemode=spectator] run return run function bse:msg_settings_spectator
execute if score #game bse.status matches 1.. run return run function bse:msg_settings_ingame
execute if score #overworld_enabled bse.config matches 1 run scoreboard players set #overworld_enabled bse.config 0
execute if score #overworld_enabled bse.config matches 0 run scoreboard players set #overworld_enabled bse.config 1
execute if score #language bse.language matches 0 run tellraw @s [{"text":"[BSE] Overworld blocks ","color":"green"},{"score":{"name":"#overworld_enabled","objective":"bse.config"}},{"text":" (0=disabled, 1=enabled)","color":"gray"}]
execute if score #language bse.language matches 1 run tellraw @s [{"text":"[BSE] Bloques del Overworld ","color":"green"},{"score":{"name":"#overworld_enabled","objective":"bse.config"}},{"text":" (0=deshabilitado, 1=habilitado)","color":"gray"}]