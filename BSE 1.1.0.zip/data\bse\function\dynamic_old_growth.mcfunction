# Old growth: spruce family + podzol/moss
execute store result score @s bse.rand run random value 1..5
execute if score @s bse.rand matches 1 run scoreboard players set @s bse.target 12
execute if score @s bse.rand matches 2 run scoreboard players set @s bse.target 46
execute if score @s bse.rand matches 3 run scoreboard players set @s bse.target 47
execute if score @s bse.rand matches 4 run scoreboard players set @s bse.target 37
execute if score @s bse.rand matches 5 run scoreboard players set @s bse.target 36
