$data modify storage bse:game target set from storage bse:blocks Blocks[$(rand)]
