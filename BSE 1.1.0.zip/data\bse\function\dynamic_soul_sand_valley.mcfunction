# Soul Sand Valley: soul sand, soul soil, crying obsidian
execute store result score @s bse.rand run random value 1..3
execute if score @s bse.rand matches 1 run scoreboard players set @s bse.target 19
execute if score @s bse.rand matches 2 run scoreboard players set @s bse.target 20
execute if score @s bse.rand matches 3 run scoreboard players set @s bse.target 23
