function bse:pick_random
function bse:translate_name
tellraw @a [{"text":"[BSE] [Ronda ","color":"yellow"},{"score":{"name":"#round","objective":"bse.round"}},{"text":"/"},{"score":{"name":"#total_rounds","objective":"bse.config"}},{"text":"] ¡Nueva ronda! "},{"nbt":"pretty","storage":"bse:game","color":"aqua","bold":true}]
title @a title [{"text":"Ronda "},{"score":{"name":"#round","objective":"bse.round"}}]
title @a subtitle [{"nbt":"pretty","storage":"bse:game"}]
