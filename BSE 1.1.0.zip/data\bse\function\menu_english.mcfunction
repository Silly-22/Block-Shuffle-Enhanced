tellraw @s {"text":""}
tellraw @s {"text":"===== Block Shuffle Enhanced 1.1.0 =====","color":"aqua","bold":true}
tellraw @s [{"text":"[▶ START GAME]","color":"green","bold":true,"click_event":{"action":"run_command","command":"/trigger bse.start"}},{"text":"  "},{"text":"[■ STOP GAME]","color":"red","bold":true,"click_event":{"action":"run_command","command":"/trigger bse.stop"}}]
tellraw @s [{"text":"[⚙ SETTINGS]","color":"yellow","click_event":{"action":"run_command","command":"/trigger bse.config_menu"},"hover_event":{"action":"show_text","value":"Open settings"}}]
tellraw @s {"text":"========================================","color":"dark_gray"}
tellraw @s [{"text":"Tip: reopen anytime with ","color":"dark_gray"},{"text":"/trigger bse.menu","color":"gray"}]
