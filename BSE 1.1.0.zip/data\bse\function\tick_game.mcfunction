scoreboard players remove #timer bse.timer 1
execute if score #timer bse.timer matches ..0 run scoreboard players set #timer bse.timer 0
scoreboard players operation #sec_total bse.sec_total = #timer bse.timer
scoreboard players operation #sec_total bse.sec_total /= #20 bse.20
scoreboard players operation #min bse.min = #sec_total bse.sec_total
scoreboard players operation #min bse.min /= #60 bse.config
scoreboard players operation #sec bse.sec = #sec_total bse.sec_total
scoreboard players operation #sec bse.sec %= #60 bse.config

# Timer color by remaining % of round (uses #max_timer):
# 0 = green (>50%), 1 = yellow (25–50%), 2 = red (<25%)
scoreboard players set #timer_color bse.config 0
scoreboard players operation #half bse.rand = #max_timer bse.max_timer
scoreboard players operation #half bse.rand /= #2 bse.20
scoreboard players operation #quarter bse.rand = #max_timer bse.max_timer
scoreboard players operation #quarter bse.rand /= #4 bse.20
execute if score #timer bse.timer <= #half bse.rand run scoreboard players set #timer_color bse.config 1
execute if score #timer bse.timer <= #quarter bse.rand run scoreboard players set #timer_color bse.config 2

execute if score #dynamic bse.config matches 1 as @a[tag=bse_playing,scores={bse.found=0}] at @s run function bse:dynamic_check
execute unless score #dynamic bse.config matches 1 as @a[tag=bse_playing,scores={bse.found=0}] at @s run function bse:check_player with storage bse:game
execute as @a[tag=bse_playing] run function bse:show_block
execute if score #timer bse.timer matches 0 run return run function bse:round_end
execute unless entity @a[tag=bse_playing,scores={bse.found=0}] run function bse:round_end
