execute if score #language bse.language matches 0 run tellraw @s {"text":"[BSE] You can't change settings in spectator mode.","color":"red"}
execute if score #language bse.language matches 1 run tellraw @s {"text":"[BSE] No puedes cambiar los ajustes en modo espectador.","color":"red"}
return fail
