# Check the block occupied by the player, then the block below their feet.
execute positioned ~ ~ ~ run function bse:dynamic_check_at
execute positioned ~ ~-0.01 ~ run function bse:dynamic_check_at
execute positioned ~ ~-1 ~ run function bse:dynamic_check_at
