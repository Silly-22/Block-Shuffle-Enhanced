tellraw @s {"text":""}
tellraw @s {"text":"--- AJUSTES DE DIMENSIONES ---","color":"green","bold":true}
execute if score #nether_enabled bse.config matches 1 run tellraw @s [{"text":"BSE Nether: true","color":"red"}]
execute if score #nether_enabled bse.config matches 0 run tellraw @s [{"text":"BSE Nether: false","color":"gray"}]
execute if score #end_enabled bse.config matches 1 run tellraw @s [{"text":"BSE End: true","color":"dark_purple"}]
execute if score #end_enabled bse.config matches 0 run tellraw @s [{"text":"BSE End: false","color":"gray"}]
execute if score #overworld_enabled bse.config matches 1 run tellraw @s [{"text":"BSE Overworld: true","color":"green"}]
execute if score #overworld_enabled bse.config matches 0 run tellraw @s [{"text":"BSE Overworld: false","color":"gray"}]
tellraw @s {"text":""}
tellraw @s {"text":"Comandos disponibles:","color":"yellow"}
tellraw @s [{"text":"/function bse:config/nether/enable","color":"white"}]
tellraw @s [{"text":"/function bse:config/nether/disable","color":"white"}]
tellraw @s [{"text":"/function bse:config/end/enable","color":"white"}]
tellraw @s [{"text":"/function bse:config/end/disable","color":"white"}]
tellraw @s [{"text":"/function bse:config/overworld/enable","color":"white"}]
tellraw @s [{"text":"/function bse:config/overworld/disable","color":"white"}]
tellraw @s {"text":""}
tellraw @s [{"text":"[← VOLVER A AJUSTES]","color":"gray","click_event":{"action":"run_command","command":"/trigger bse.config_menu"}}]
tellraw @s {"text":"========================================","color":"dark_gray"}