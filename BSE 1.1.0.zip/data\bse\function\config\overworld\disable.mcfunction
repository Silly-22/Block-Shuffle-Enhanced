execute if entity @s[gamemode=spectator] run return run function bse:msg_settings_spectator
execute if score #game bse.status matches 1.. run return run function bse:msg_settings_ingame
scoreboard players set #overworld_enabled bse.config 0
execute if score #language bse.language matches 0 run tellraw @s [{"text":"[BSE] Overworld blocks disabled","color":"green"}]
execute if score #language bse.language matches 1 run tellraw @s [{"text":"[BSE] Bloques del Overworld deshabilitados","color":"green"}]
function bse:setup_blocks
execute if score #game bse.status matches 1 run function bse:new_round
function bse:warn_no_dimensions
