execute if score #dynamic bse.config matches 1 run function bse:dynamic_show
execute unless score #dynamic bse.config matches 1 run function bse:show_timer_color
