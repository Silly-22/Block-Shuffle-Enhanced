execute as @a[tag=bse_playing] at @s run function bse:dynamic_assign
tellraw @a {"text":"[BSE] Dynamic Round: each player has an objective based on their biome.","color":"light_purple"}
execute as @a[tag=bse_playing] run function bse:dynamic_announce
