execute as @a[tag=bse_playing] at @s run function bse:dynamic_assign
tellraw @a {"text":"[BSE] Ronda Dinámica: cada jugador tiene un objetivo basado en su bioma.","color":"light_purple"}
execute as @a[tag=bse_playing] run function bse:dynamic_announce
