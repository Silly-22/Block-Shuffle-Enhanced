execute if entity @s[gamemode=spectator] run return run function bse:msg_settings_spectator
execute if score #game bse.status matches 1.. run return run function bse:msg_settings_ingame
scoreboard players set #max_lives bse.lives 5
tellraw @a {"text":"[BSE] Vidas del jugador establecidas: 5","color":"light_purple"}
function bse:config_menu
