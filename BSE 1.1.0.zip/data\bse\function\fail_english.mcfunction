scoreboard players remove @s bse.lives 1
execute if score @s bse.lives matches 1.. run title @s title {"text":"Objective Failed!","color":"gold"}
execute if score @s bse.lives matches 1.. run tellraw @s [{"text":"[BSE] You have ","color":"yellow"},{"score":{"name":"@s","objective":"bse.lives"}},{"text":" lives remaining.","color":"yellow"}]
execute if score @s bse.lives matches ..0 run title @s title {"text":"Eliminated","color":"red"}
execute if score @s bse.lives matches ..0 run tag @s remove bse_playing
# Multi only: spectator. Solo keeps survival so the world stays playable.
execute if score @s bse.lives matches ..0 if score #mode bse.config matches 1 run gamemode spectator @s
execute if score @s bse.lives matches ..0 if score #mode bse.config matches 0 run tellraw @s {"text":"[BSE] Eliminated. Settings stay locked until the game ends.","color":"gray"}
