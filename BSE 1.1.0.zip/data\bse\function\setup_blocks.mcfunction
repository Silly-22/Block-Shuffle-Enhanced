data modify storage bse:blocks Blocks set value []

# Overworld pool (original list, excluding the misplaced netherrack)
execute if score #overworld_enabled bse.config matches 1 run data modify storage bse:blocks Blocks set value ["minecraft:grass_block","minecraft:dirt","minecraft:stone","minecraft:cobblestone","minecraft:oak_log","minecraft:spruce_log","minecraft:birch_log","minecraft:jungle_log","minecraft:acacia_log","minecraft:dark_oak_log","minecraft:sand","minecraft:red_sand","minecraft:gravel","minecraft:clay","minecraft:coal_ore","minecraft:iron_ore","minecraft:copper_ore","minecraft:gold_ore","minecraft:diamond_ore","minecraft:emerald_ore","minecraft:deepslate","minecraft:cobbled_deepslate","minecraft:andesite","minecraft:diorite","minecraft:granite","minecraft:tuff","minecraft:calcite","minecraft:dripstone_block","minecraft:amethyst_block","minecraft:smooth_basalt","minecraft:obsidian","minecraft:moss_block","minecraft:moss_carpet","minecraft:azalea","minecraft:flowering_azalea","minecraft:oak_leaves","minecraft:spruce_leaves","minecraft:birch_leaves","minecraft:jungle_leaves","minecraft:acacia_leaves","minecraft:dark_oak_leaves","minecraft:vine","minecraft:fern","minecraft:large_fern","minecraft:dead_bush","minecraft:dandelion","minecraft:poppy","minecraft:blue_orchid","minecraft:allium","minecraft:azure_bluet","minecraft:red_tulip","minecraft:orange_tulip","minecraft:white_tulip","minecraft:pink_tulip","minecraft:oxeye_daisy","minecraft:cornflower","minecraft:lily_of_the_valley","minecraft:sunflower","minecraft:rose_bush","minecraft:peony","minecraft:white_wool","minecraft:orange_wool","minecraft:magenta_wool","minecraft:light_blue_wool","minecraft:yellow_wool","minecraft:lime_wool","minecraft:pink_wool","minecraft:gray_wool","minecraft:light_gray_wool","minecraft:cyan_wool","minecraft:purple_wool","minecraft:blue_wool","minecraft:brown_wool","minecraft:green_wool","minecraft:red_wool","minecraft:black_wool","minecraft:glass","minecraft:crafting_table","minecraft:furnace","minecraft:chest","minecraft:ladder","minecraft:torch","minecraft:bookshelf","minecraft:jukebox","minecraft:note_block","minecraft:campfire","minecraft:barrel","minecraft:smoker","minecraft:blast_furnace","minecraft:stonecutter","minecraft:anvil","minecraft:hay_block","minecraft:pumpkin","minecraft:melon_block","minecraft:sugar_cane","minecraft:cactus","minecraft:bamboo","minecraft:cobweb","minecraft:snow_block","minecraft:ice","minecraft:packed_ice","minecraft:glow_lichen"]

# Nether pool
execute if score #nether_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:netherrack"
execute if score #nether_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:basalt"
execute if score #nether_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:blackstone"
execute if score #nether_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:soul_sand"
execute if score #nether_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:soul_soil"
execute if score #nether_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:magma_block"
execute if score #nether_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:glowstone"
execute if score #nether_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:shroomlight"
execute if score #nether_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:crying_obsidian"
execute if score #nether_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:nether_bricks"
execute if score #nether_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:red_nether_bricks"
execute if score #nether_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:quartz_block"
execute if score #nether_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:nether_quartz_ore"
execute if score #nether_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:nether_gold_ore"
execute if score #nether_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:crimson_nylium"
execute if score #nether_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:warped_nylium"
execute if score #nether_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:crimson_stem"
execute if score #nether_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:warped_stem"
execute if score #nether_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:nether_wart_block"
execute if score #nether_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:warped_wart_block"

# End pool
execute if score #end_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:end_stone"
execute if score #end_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:end_stone_bricks"
execute if score #end_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:purpur_block"
execute if score #end_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:purpur_pillar"
execute if score #end_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:chorus_plant"
execute if score #end_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:chorus_flower"
execute if score #end_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:obsidian"
execute if score #end_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:end_rod"
execute if score #end_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:purpur_stairs"
execute if score #end_enabled bse.config matches 1 run data modify storage bse:blocks Blocks append value "minecraft:purpur_slab"
