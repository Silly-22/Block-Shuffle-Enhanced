execute unless entity @a[tag=bse_team_red] run tellraw @s {"text":"[BSE] At least one player is needed on the Red Team.","color":"red"}
execute unless entity @a[tag=bse_team_blue] run tellraw @s {"text":"[BSE] At least one player is needed on the Blue Team.","color":"red"}
execute if entity @a[tag=bse_team_red] if entity @a[tag=bse_team_blue] run scoreboard players set #mode bse.config 1
execute if entity @a[tag=bse_team_red] if entity @a[tag=bse_team_blue] run function bse:start
