# This function receives storage bse:game, which contains target.
# The guard prevents detecting the same target twice in one tick.
$execute unless score @s bse.found matches 1 if block ~ ~ ~ $(target) run function bse:success
