function bse:pick_random
function bse:translate_name
tellraw @a [{"text":"[BSE] [Round ","color":"yellow"},{"score":{"name":"#round","objective":"bse.round"}},{"text":"/"},{"score":{"name":"#total_rounds","objective":"bse.config"}},{"text":"] New Round! "},{"nbt":"pretty","storage":"bse:game","color":"aqua","bold":true}]
title @a title [{"text":"Round "},{"score":{"name":"#round","objective":"bse.round"}}]
title @a subtitle [{"nbt":"pretty","storage":"bse:game"}]
