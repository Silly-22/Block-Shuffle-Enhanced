scoreboard players set @s bse.found 1
title @s title {"text":"Objective Complete!","color":"green"}
execute if score #dynamic bse.config matches 1 run title @s subtitle {"text":"Biome objective complete","color":"green"}
execute unless score #dynamic bse.config matches 1 run title @s subtitle [{"nbt":"pretty","storage":"bse:game"}]
