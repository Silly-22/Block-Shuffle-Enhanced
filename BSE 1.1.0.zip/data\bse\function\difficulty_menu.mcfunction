execute if score #language bse.language matches 0 run function bse:difficulty_menu_english
execute if score #language bse.language matches 1 run function bse:difficulty_menu_spanish
