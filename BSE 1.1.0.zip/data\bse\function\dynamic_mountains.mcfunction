# Mountains: stone family variants + deepslate
execute store result score @s bse.rand run random value 1..6
execute if score @s bse.rand matches 1 run scoreboard players set @s bse.target 16
execute if score @s bse.rand matches 2 run scoreboard players set @s bse.target 18
execute if score @s bse.rand matches 3 run scoreboard players set @s bse.target 41
execute if score @s bse.rand matches 4 run scoreboard players set @s bse.target 58
execute if score @s bse.rand matches 5 run scoreboard players set @s bse.target 59
execute if score @s bse.rand matches 6 run scoreboard players set @s bse.target 60
