execute if score #language bse.language matches 0 run function bse:show_block_english
execute if score #language bse.language matches 1 run function bse:show_block_spanish
