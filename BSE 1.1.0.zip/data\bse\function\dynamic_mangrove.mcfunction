# Mangrove: mangrove log + planks/stairs, mud, clay
execute store result score @s bse.rand run random value 1..5
execute if score @s bse.rand matches 1 run scoreboard players set @s bse.target 33
execute if score @s bse.rand matches 2 run scoreboard players set @s bse.target 54
execute if score @s bse.rand matches 3 run scoreboard players set @s bse.target 55
execute if score @s bse.rand matches 4 run scoreboard players set @s bse.target 32
execute if score @s bse.rand matches 5 run scoreboard players set @s bse.target 40
