scoreboard players set #game bse.status 2
execute as @a[tag=bse_playing,scores={bse.found=0}] at @s run function bse:fail
execute unless entity @a[tag=bse_playing] run return run function bse:game_over
execute if score #round bse.round >= #total_rounds bse.config run return run function bse:win_game
tellraw @a [{"text":"[BSE] ¡Ronda completa! Siguiente ronda en 3s...","color":"green"}]
schedule function bse:next_round 3s
