scoreboard players set #language bse.language 1
tag @s add bse_language_selected
function bse:menu_spanish
