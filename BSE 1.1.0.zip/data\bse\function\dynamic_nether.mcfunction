execute store result score @s bse.rand run random value 19..24
scoreboard players operation @s bse.target = @s bse.rand
