# Snow / taiga: spruce family + snow/ice
execute store result score @s bse.rand run random value 1..6
execute if score @s bse.rand matches 1 run scoreboard players set @s bse.target 10
execute if score @s bse.rand matches 2 run scoreboard players set @s bse.target 11
execute if score @s bse.rand matches 3 run scoreboard players set @s bse.target 12
execute if score @s bse.rand matches 4 run scoreboard players set @s bse.target 46
execute if score @s bse.rand matches 5 run scoreboard players set @s bse.target 47
execute if score @s bse.rand matches 6 run scoreboard players set @s bse.target 38
