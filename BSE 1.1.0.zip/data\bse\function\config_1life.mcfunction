execute if entity @s[gamemode=spectator] run return run function bse:msg_settings_spectator
execute if score #game bse.status matches 1.. run return run function bse:msg_settings_ingame
execute if score #language bse.language matches 0 run function bse:config_1life_english
execute if score #language bse.language matches 1 run function bse:config_1life_spanish
