scoreboard players set #language bse.language 1
tellraw @s [{"text":"[BSE] Idioma establecido a Español","color":"green"}]
function bse:config_menu
