execute if score #language bse.language matches 0 run function bse:stop_english
execute if score #language bse.language matches 1 run function bse:stop_spanish
