execute if entity @s[gamemode=spectator] run return run function bse:msg_settings_spectator
execute if score #game bse.status matches 1.. run return run function bse:msg_settings_ingame
scoreboard players set #max_lives bse.lives 1
tellraw @a {"text":"[BSE] Player Lives set: 1","color":"red"}
function bse:config_menu
