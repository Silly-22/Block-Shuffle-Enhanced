execute store result score #size bse.rand run data get storage bse:blocks Blocks
execute if score #size bse.rand matches 0 run data modify storage bse:game target set value ""
execute if score #size bse.rand matches 0 run data modify storage bse:game pretty set value ""
execute if score #size bse.rand matches 1.. store result score #rand bse.rand run random value 0..2147483646
execute if score #size bse.rand matches 1.. run scoreboard players operation #rand bse.rand %= #size bse.rand
execute if score #size bse.rand matches 1.. store result storage bse:temp rand int 1 run scoreboard players get #rand bse.rand
execute if score #size bse.rand matches 1.. run function bse:apply_random with storage bse:temp
execute if score #size bse.rand matches 1.. run function bse:filter_difficulty
