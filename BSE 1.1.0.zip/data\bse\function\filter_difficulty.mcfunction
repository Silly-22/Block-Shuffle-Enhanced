# Dynamic difficulty by selected time.
# 1 minuto: estos bloques se vuelven a sortear para evitar objetivos lentos.
execute if score #round_time bse.config matches 1200 if data storage bse:game {target:"minecraft:diamond_ore"} run function bse:pick_random
execute if score #round_time bse.config matches 1200 if data storage bse:game {target:"minecraft:deepslate_diamond_ore"} run function bse:pick_random
execute if score #round_time bse.config matches 1200 if data storage bse:game {target:"minecraft:diamond_block"} run function bse:pick_random
execute if score #round_time bse.config matches 1200 if data storage bse:game {target:"minecraft:emerald_ore"} run function bse:pick_random
execute if score #round_time bse.config matches 1200 if data storage bse:game {target:"minecraft:deepslate_emerald_ore"} run function bse:pick_random
execute if score #round_time bse.config matches 1200 if data storage bse:game {target:"minecraft:obseidian"} run function bse:pick_random
execute if score #round_time bse.config matches 1200 if data storage bse:game {target:"minecraft:amethyst_block"} run function bse:pick_random

# 90 seconds: exclude only the rarest mining targets.
execute if score #round_time bse.config matches 1800 if data storage bse:game {target:"minecraft:diamond_ore"} run function bse:pick_random
execute if score #round_time bse.config matches 1800 if data storage bse:game {target:"minecraft:deepslate_diamond_ore"} run function bse:pick_random
execute if score #round_time bse.config matches 1800 if data storage bse:game {target:"minecraft:diamond_block"} run function bse:pick_random
execute if score #round_time bse.config matches 1800 if data storage bse:game {target:"minecraft:emerald_ore"} run function bse:pick_random
execute if score #round_time bse.config matches 1800 if data storage bse:game {target:"minecraft:deepslate_emerald_ore"} run function bse:pick_random
