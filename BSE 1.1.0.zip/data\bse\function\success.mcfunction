scoreboard players set @s bse.found 1
execute if score #language bse.language matches 0 run function bse:success_english
execute if score #language bse.language matches 1 run function bse:success_spanish
