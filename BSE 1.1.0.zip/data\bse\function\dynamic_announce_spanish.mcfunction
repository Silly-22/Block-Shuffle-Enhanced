title @s title {"text":"Ronda Dinámica","color":"light_purple"}
function bse:dynamic_show
