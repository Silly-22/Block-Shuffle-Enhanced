execute if entity @s[gamemode=spectator] run return run function bse:msg_settings_spectator
execute if score #game bse.status matches 1.. run return run function bse:msg_settings_ingame
scoreboard players set #end_enabled bse.config 0
execute if score #language bse.language matches 0 run tellraw @s [{"text":"[BSE] End blocks disabled","color":"dark_purple"}]
execute if score #language bse.language matches 1 run tellraw @s [{"text":"[BSE] Bloques del End deshabilitados","color":"dark_purple"}]
function bse:setup_blocks
execute if score #game bse.status matches 1 run function bse:new_round
function bse:warn_no_dimensions
