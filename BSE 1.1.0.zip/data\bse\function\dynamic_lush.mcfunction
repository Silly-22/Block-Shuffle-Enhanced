# Lush / dripstone caves: moss, clay, amethyst, dirt
execute store result score @s bse.rand run random value 1..4
execute if score @s bse.rand matches 1 run scoreboard players set @s bse.target 36
execute if score @s bse.rand matches 2 run scoreboard players set @s bse.target 40
execute if score @s bse.rand matches 3 run scoreboard players set @s bse.target 42
execute if score @s bse.rand matches 4 run scoreboard players set @s bse.target 17
