tellraw @a [{"text":"[BSE] ¡Juego Terminado! Nadie sobrevivió.","color":"red"}]
scoreboard players set #game bse.status 0
execute as @a run function bse:menu
