# Outer islands highlands: purpur + chorus
execute store result score @s bse.rand run random value 27..30
scoreboard players operation @s bse.target = @s bse.rand
