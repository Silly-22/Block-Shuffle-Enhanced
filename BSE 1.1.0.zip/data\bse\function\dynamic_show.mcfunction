execute if score #language bse.language matches 0 run function bse:dynamic_show_english
execute if score #language bse.language matches 1 run function bse:dynamic_show_spanish
