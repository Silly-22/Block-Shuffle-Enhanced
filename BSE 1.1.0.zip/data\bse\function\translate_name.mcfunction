execute if score #language bse.language matches 0 run function bse:translate_name_english
execute if score #language bse.language matches 1 run function bse:translate_name_spanish
execute unless data storage bse:game pretty run data modify storage bse:game pretty set from storage bse:game target
execute if data storage bse:game {pretty:""} run data modify storage bse:game pretty set from storage bse:game target
