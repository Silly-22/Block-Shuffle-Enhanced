data modify storage bse:game pretty set value ""
scoreboard players set @s bse.target 0

# ---- Overworld biomes (flag only; biome ids are exclusive to OW) ----
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:desert run function bse:dynamic_desert
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:badlands run function bse:dynamic_desert
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:wooded_badlands run function bse:dynamic_desert
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:eroded_badlands run function bse:dynamic_desert

execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:forest run function bse:dynamic_forest
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:birch_forest run function bse:dynamic_forest
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:dark_forest run function bse:dynamic_forest
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:flower_forest run function bse:dynamic_forest

execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:jungle run function bse:dynamic_jungle
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:bamboo_jungle run function bse:dynamic_jungle
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:sparse_jungle run function bse:dynamic_jungle

execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:snowy_plains run function bse:dynamic_snow
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:snowy_taiga run function bse:dynamic_snow
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:taiga run function bse:dynamic_snow
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:snowy_slopes run function bse:dynamic_snow
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:grove run function bse:dynamic_snow

execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:plains run function bse:dynamic_plains
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:sunflower_plains run function bse:dynamic_plains
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:meadow run function bse:dynamic_plains

execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:savanna run function bse:dynamic_savanna
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:savanna_plateau run function bse:dynamic_savanna
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:windswept_savanna run function bse:dynamic_savanna

execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:swamp run function bse:dynamic_swamp
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:mangrove_swamp run function bse:dynamic_mangrove

execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:ocean run function bse:dynamic_ocean
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:warm_ocean run function bse:dynamic_ocean
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:lukewarm_ocean run function bse:dynamic_ocean
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:cold_ocean run function bse:dynamic_ocean
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:deep_ocean run function bse:dynamic_ocean
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:deep_lukewarm_ocean run function bse:dynamic_ocean
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:deep_cold_ocean run function bse:dynamic_ocean
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:beach run function bse:dynamic_ocean
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:stony_shore run function bse:dynamic_ocean
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:river run function bse:dynamic_ocean

execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:cherry_grove run function bse:dynamic_cherry

execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:old_growth_pine_taiga run function bse:dynamic_old_growth
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:old_growth_spruce_taiga run function bse:dynamic_old_growth

execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:windswept_hills run function bse:dynamic_mountains
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:windswept_gravelly_hills run function bse:dynamic_mountains
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:windswept_forest run function bse:dynamic_mountains
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:stony_peaks run function bse:dynamic_mountains
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:jagged_peaks run function bse:dynamic_mountains
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:frozen_peaks run function bse:dynamic_mountains

execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:lush_caves run function bse:dynamic_lush
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:dripstone_caves run function bse:dynamic_lush

execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:frozen_ocean run function bse:dynamic_frozen
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:deep_frozen_ocean run function bse:dynamic_frozen
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:frozen_river run function bse:dynamic_frozen
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:snowy_beach run function bse:dynamic_frozen
execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:ice_spikes run function bse:dynamic_frozen

execute if score #overworld_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:mushroom_fields run function bse:dynamic_mushroom

# ---- Nether: dimension + biome ----
execute if score #nether_enabled bse.config matches 1 if dimension minecraft:the_nether if biome ~ ~ ~ minecraft:nether_wastes run function bse:dynamic_nether_wastes
execute if score #nether_enabled bse.config matches 1 if dimension minecraft:the_nether if biome ~ ~ ~ minecraft:basalt_deltas run function bse:dynamic_basalt_deltas
execute if score #nether_enabled bse.config matches 1 if dimension minecraft:the_nether if biome ~ ~ ~ minecraft:soul_sand_valley run function bse:dynamic_soul_sand_valley
execute if score #nether_enabled bse.config matches 1 if dimension minecraft:the_nether if biome ~ ~ ~ minecraft:crimson_forest run function bse:dynamic_crimson_forest
execute if score #nether_enabled bse.config matches 1 if dimension minecraft:the_nether if biome ~ ~ ~ minecraft:warped_forest run function bse:dynamic_warped_forest
# Nether biome-only backup (in case dimension check fails)
execute unless score @s bse.target matches 1.. if score #nether_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:nether_wastes run function bse:dynamic_nether_wastes
execute unless score @s bse.target matches 1.. if score #nether_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:basalt_deltas run function bse:dynamic_basalt_deltas
execute unless score @s bse.target matches 1.. if score #nether_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:soul_sand_valley run function bse:dynamic_soul_sand_valley
execute unless score @s bse.target matches 1.. if score #nether_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:crimson_forest run function bse:dynamic_crimson_forest
execute unless score @s bse.target matches 1.. if score #nether_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:warped_forest run function bse:dynamic_warped_forest

# ---- End: dimension + biome ----
execute if score #end_enabled bse.config matches 1 if dimension minecraft:the_end if biome ~ ~ ~ minecraft:the_end run function bse:dynamic_end_center
execute if score #end_enabled bse.config matches 1 if dimension minecraft:the_end if biome ~ ~ ~ minecraft:end_barrens run function bse:dynamic_end_center
execute if score #end_enabled bse.config matches 1 if dimension minecraft:the_end if biome ~ ~ ~ minecraft:end_highlands run function bse:dynamic_end_highlands
execute if score #end_enabled bse.config matches 1 if dimension minecraft:the_end if biome ~ ~ ~ minecraft:end_midlands run function bse:dynamic_end_midlands
execute if score #end_enabled bse.config matches 1 if dimension minecraft:the_end if biome ~ ~ ~ minecraft:small_end_islands run function bse:dynamic_end_islands
execute unless score @s bse.target matches 1.. if score #end_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:the_end run function bse:dynamic_end_center
execute unless score @s bse.target matches 1.. if score #end_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:end_barrens run function bse:dynamic_end_center
execute unless score @s bse.target matches 1.. if score #end_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:end_highlands run function bse:dynamic_end_highlands
execute unless score @s bse.target matches 1.. if score #end_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:end_midlands run function bse:dynamic_end_midlands
execute unless score @s bse.target matches 1.. if score #end_enabled bse.config matches 1 if biome ~ ~ ~ minecraft:small_end_islands run function bse:dynamic_end_islands

# ---- Fallbacks among enabled dimensions ----
execute unless score @s bse.target matches 1.. if score #overworld_enabled bse.config matches 1 run function bse:dynamic_default
execute unless score @s bse.target matches 1.. if score #nether_enabled bse.config matches 1 run function bse:dynamic_nether
execute unless score @s bse.target matches 1.. if score #end_enabled bse.config matches 1 run function bse:dynamic_end

# ---- Hard guarantee: never leave target at 0 if at least one dimension is enabled ----
execute unless score @s bse.target matches 1.. if score #overworld_enabled bse.config matches 1 run scoreboard players set @s bse.target 16
execute unless score @s bse.target matches 1.. if score #nether_enabled bse.config matches 1 run scoreboard players set @s bse.target 13
execute unless score @s bse.target matches 1.. if score #end_enabled bse.config matches 1 run scoreboard players set @s bse.target 25
