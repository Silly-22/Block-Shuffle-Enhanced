execute if entity @s[gamemode=spectator] run return run function bse:msg_settings_spectator
execute if score #game bse.status matches 1.. run return run function bse:msg_settings_ingame
scoreboard players set #round_time bse.config 3600
execute if score #await_dyn_time bse.config matches 1 run scoreboard players set #dynamic bse.config 1
execute unless score #await_dyn_time bse.config matches 1 run scoreboard players set #dynamic bse.config 0
execute if score #await_dyn_time bse.config matches 1 run tellraw @a [{"text":"[BSE] Modo dinámico — Tiempo ajustado: 3m","color":"light_purple"}]
execute unless score #await_dyn_time bse.config matches 1 run tellraw @a [{"text":"[BSE] Tiempo ajustado: 3m","color":"green"}]
scoreboard players set #await_dyn_time bse.config 0
function bse:menu
