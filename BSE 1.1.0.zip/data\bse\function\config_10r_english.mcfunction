execute if entity @s[gamemode=spectator] run return run function bse:msg_settings_spectator
execute if score #game bse.status matches 1.. run return run function bse:msg_settings_ingame
scoreboard players set #total_rounds bse.config 10
tellraw @a [{"text":"[BSE] Rounds set: 10","color":"gold"}]
function bse:menu
