# Checks the block occupied by the player (plants, vines, etc.).
execute positioned ~ ~ ~ run function bse:check_target with storage bse:game

# Checks directly below the player's feet. The small offset also supports
# non-full-height blocks such as slabs, snow layers, and carpets.
execute positioned ~ ~-0.01 ~ run function bse:check_target with storage bse:game

# Fallback for positions slightly raised by movement or collisions.
execute positioned ~ ~-1 ~ run function bse:check_target with storage bse:game
