execute unless score #overworld_enabled bse.config matches 0 run return 0
execute unless score #nether_enabled bse.config matches 0 run return 0
execute unless score #end_enabled bse.config matches 0 run return 0
execute if score #language bse.language matches 0 run tellraw @a [{"text":"[BSE] ","color":"red","bold":true},{"text":"All dimensions are disabled. No objectives will be assigned until at least one dimension is enabled.","color":"red","bold":false}]
execute if score #language bse.language matches 1 run tellraw @a [{"text":"[BSE] ","color":"red","bold":true},{"text":"Todas las dimensiones están deshabilitadas. No se asignarán objetivos hasta que habilites al menos una.","color":"red","bold":false}]
