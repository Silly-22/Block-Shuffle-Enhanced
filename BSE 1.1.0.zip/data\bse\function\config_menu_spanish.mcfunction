tellraw @s {"text":""}
tellraw @s {"text":"--- AJUSTES ---","color":"yellow","bold":true}
tellraw @s [{"text":"[⏱ TIEMPO]","color":"yellow","click_event":{"action":"run_command","command":"/trigger bse.difficulty_menu"}}]
tellraw @s [{"text":"[⚙ CONFIGURAR RONDAS]","color":"light_purple","click_event":{"action":"run_command","command":"/trigger bse.rounds_menu"}}]
tellraw @s [{"text":"[♥ AJUSTAR VIDAS: ","color":"red"},{"score":{"name":"#max_lives","objective":"bse.lives"}},{"text":"]","color":"red"},{"text":" ","color":"white"},{"text":"[CAMBIAR]","color":"gold","click_event":{"action":"run_command","command":"/trigger bse.lives_menu"}}]
tellraw @s [{"text":"[🌐 IDIOMA]","color":"aqua","click_event":{"action":"run_command","command":"/trigger bse.language_menu"}}]
tellraw @s [{"text":"[🌍 DIMENSIONES]","color":"green","click_event":{"action":"run_command","command":"/trigger bse.dimension_menu"}}]
tellraw @s [{"text":"[? TIPS / AYUDA]","color":"gold","click_event":{"action":"run_command","command":"/trigger bse.tips"}}]
tellraw @s [{"text":"[← VOLVER AL MENU]","color":"gray","click_event":{"action":"run_command","command":"/trigger bse.menu"}}]
tellraw @s {"text":"========================================","color":"dark_gray"}
