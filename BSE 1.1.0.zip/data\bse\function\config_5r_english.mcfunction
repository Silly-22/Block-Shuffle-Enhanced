execute if entity @s[gamemode=spectator] run return run function bse:msg_settings_spectator
execute if score #game bse.status matches 1.. run return run function bse:msg_settings_ingame
scoreboard players set #total_rounds bse.config 5
tellraw @a [{"text":"[BSE] Rounds set: 5","color":"green"}]
function bse:menu
