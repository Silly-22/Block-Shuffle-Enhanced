scoreboard players set #language bse.language 0
tag @s add bse_language_selected
function bse:menu_english
