execute if score #language bse.language matches 0 run function bse:tips_english
execute if score #language bse.language matches 1 run function bse:tips_spanish
