# Central island / barrens: end stone, obsidian
execute store result score @s bse.rand run random value 1..2
execute if score @s bse.rand matches 1 run scoreboard players set @s bse.target 25
execute if score @s bse.rand matches 2 run scoreboard players set @s bse.target 26
