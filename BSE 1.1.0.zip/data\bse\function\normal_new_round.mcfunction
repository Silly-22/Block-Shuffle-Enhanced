function bse:pick_random
function bse:translate_name
tellraw @a [{"text":"[Round ","color":"yellow"},{"score":{"name":"#round","objective":"bs.round"}},{"text":"/"},{"score":{"name":"#total_rounds","objective":"bs.config"}},{"text":"] New Round! "},{"nbt":"pretty","storage":"bse:game","color":"aqua","bold":true}]
title @a title [{"text":"Round "},{"score":{"name":"#round","objective":"bs.round"}}]
title @a subtitle [{"nbt":"pretty","storage":"bse:game"}]
