execute unless entity @s[tag=bse_language_selected] run function bse:select_language
execute if entity @s[tag=bse_language_selected] run function bse:menu
