# Legacy trigger: enable dynamic mode directly (no longer a beta warning)
function bse:config_dynamic
