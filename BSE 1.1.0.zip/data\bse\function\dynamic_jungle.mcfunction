# Jungle: jungle log/bamboo/vine + jungle planks/stairs
execute store result score @s bse.rand run random value 1..5
execute if score @s bse.rand matches 1 run scoreboard players set @s bse.target 7
execute if score @s bse.rand matches 2 run scoreboard players set @s bse.target 8
execute if score @s bse.rand matches 3 run scoreboard players set @s bse.target 9
execute if score @s bse.rand matches 4 run scoreboard players set @s bse.target 48
execute if score @s bse.rand matches 5 run scoreboard players set @s bse.target 49
