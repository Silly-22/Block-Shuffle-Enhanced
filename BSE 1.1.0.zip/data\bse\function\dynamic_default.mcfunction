# Varied fallback including common variants (only when OW enabled)
execute if score #overworld_enabled bse.config matches 1 store result score @s bse.rand run random value 1..8
execute if score #overworld_enabled bse.config matches 1 if score @s bse.rand matches 1 run scoreboard players set @s bse.target 4
execute if score #overworld_enabled bse.config matches 1 if score @s bse.rand matches 2 run scoreboard players set @s bse.target 43
execute if score #overworld_enabled bse.config matches 1 if score @s bse.rand matches 3 run scoreboard players set @s bse.target 44
execute if score #overworld_enabled bse.config matches 1 if score @s bse.rand matches 4 run scoreboard players set @s bse.target 16
execute if score #overworld_enabled bse.config matches 1 if score @s bse.rand matches 5 run scoreboard players set @s bse.target 18
execute if score #overworld_enabled bse.config matches 1 if score @s bse.rand matches 6 run scoreboard players set @s bse.target 58
execute if score #overworld_enabled bse.config matches 1 if score @s bse.rand matches 7 run scoreboard players set @s bse.target 41
execute if score #overworld_enabled bse.config matches 1 if score @s bse.rand matches 8 run scoreboard players set @s bse.target 6
