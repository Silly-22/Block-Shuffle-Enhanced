scoreboard players remove @s bse.lives 1
execute if score #language bse.language matches 0 run function bse:fail_english
execute if score #language bse.language matches 1 run function bse:fail_spanish
