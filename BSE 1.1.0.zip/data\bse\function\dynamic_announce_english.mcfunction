title @s title {"text":"Dynamic Round","color":"light_purple"}
function bse:dynamic_show
