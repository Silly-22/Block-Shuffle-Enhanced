tellraw @s {"text":""}
tellraw @s {"text":"--- MODO DINÁMICO: TIEMPO DE RONDA ---","color":"light_purple","bold":true}
tellraw @s {"text":"Elige cuánto dura cada ronda.","color":"gray"}
tellraw @s [{"text":"[⏱ 1m]","color":"red","click_event":{"action":"run_command","command":"/trigger bse.60"}},{"text":"  "},{"text":"[⏱ 1m 30s]","color":"gold","click_event":{"action":"run_command","command":"/trigger bse.90"}},{"text":"  "},{"text":"[⏱ 3m]","color":"green","click_event":{"action":"run_command","command":"/trigger bse.180"}},{"text":"  "},{"text":"[⏱ 5m]","color":"aqua","click_event":{"action":"run_command","command":"/trigger bse.300"}}]
tellraw @s [{"text":"[← VOLVER A TIEMPO]","color":"gray","click_event":{"action":"run_command","command":"/trigger bse.difficulty_menu"}}]
tellraw @s {"text":"========================================","color":"dark_gray"}
