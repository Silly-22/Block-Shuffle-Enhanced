scoreboard players enable @a bse.start
scoreboard players enable @a bse.solo
scoreboard players enable @a bse.multi
scoreboard players enable @a bse.team_red
scoreboard players enable @a bse.team_blue
scoreboard players enable @a bse.start_multi
scoreboard players enable @a bse.stop
scoreboard players enable @a bse.menu
scoreboard players enable @a bse.config_menu
scoreboard players enable @a bse.difficulty_menu
scoreboard players enable @a bse.rounds_menu
scoreboard players enable @a bse.rounds_5
scoreboard players enable @a bse.rounds_10
scoreboard players enable @a bse.rounds_30
scoreboard players enable @a bse.lives_menu
scoreboard players enable @a bse.lives_1
scoreboard players enable @a bse.lives_3
scoreboard players enable @a bse.lives_5
scoreboard players enable @a bse.language_menu
scoreboard players enable @a bse.set_english
scoreboard players enable @a bse.set_spanish
scoreboard players enable @a bse.init_english
scoreboard players enable @a bse.init_spanish
scoreboard players enable @a bse.dimension_menu
scoreboard players enable @a bse.tips
scoreboard players enable @a bse.toggle_nether
scoreboard players enable @a bse.toggle_end
scoreboard players enable @a bse.toggle_overworld
scoreboard players enable @a bse.60
scoreboard players enable @a bse.90
scoreboard players enable @a bse.180
scoreboard players enable @a bse.300
scoreboard players enable @a bse.dynamic_warn
scoreboard players enable @a bse.dynamic_accept
execute as @a[scores={bse.menu=1..}] run function bse:menu
execute as @a[scores={bse.config_menu=1..}] run function bse:config_menu
execute as @a[scores={bse.difficulty_menu=1..}] run function bse:difficulty_menu
execute as @a[scores={bse.rounds_menu=1..}] run function bse:rounds_menu
execute as @a[scores={bse.rounds_5=1..}] run function bse:config_5r
execute as @a[scores={bse.rounds_10=1..}] run function bse:config_10r
execute as @a[scores={bse.rounds_30=1..}] run function bse:config_30r
execute as @a[scores={bse.lives_menu=1..}] run function bse:lives_menu
execute as @a[scores={bse.lives_1=1..}] run function bse:config_1life
execute as @a[scores={bse.lives_3=1..}] run function bse:config_3lives
execute as @a[scores={bse.lives_5=1..}] run function bse:config_5lives
execute as @a[scores={bse.language_menu=1..}] run function bse:language_menu
execute as @a[scores={bse.set_english=1..}] run function bse:set_english
execute as @a[scores={bse.set_spanish=1..}] run function bse:set_spanish
execute as @a[scores={bse.init_english=1..}] run function bse:init_language_english
execute as @a[scores={bse.init_spanish=1..}] run function bse:init_language_spanish
execute as @a[scores={bse.dimension_menu=1..}] run function bse:dimension_menu
execute as @a[scores={bse.tips=1..}] run function bse:tips
execute as @a[scores={bse.toggle_nether=1..}] run function bse:toggle_nether
execute as @a[scores={bse.toggle_end=1..}] run function bse:toggle_end
execute as @a[scores={bse.toggle_overworld=1..}] run function bse:toggle_overworld
# Avisos animados para jugadores que no son el creador
execute as @a[tag=!bse_owner,scores={bse.start=1..}] run function bse:deny_start
execute as @a[tag=!bse_owner,scores={bse.solo=1..}] run function bse:deny_start
execute as @a[tag=!bse_owner,scores={bse.multi=1..}] run function bse:deny_start
execute as @a[tag=!bse_owner,scores={bse.start_multi=1..}] run function bse:deny_start
execute as @a[tag=!bse_owner,scores={bse.stop=1..}] run function bse:deny_stop

execute as @a[tag=bse_owner,scores={bse.start=1..}] run function bse:start_menu
execute as @a[tag=bse_owner,scores={bse.solo=1..}] run function bse:start_solo
execute as @a[tag=bse_owner,scores={bse.multi=1..}] run function bse:team_menu
execute as @a[scores={bse.team_red=1..}] run function bse:join_red
execute as @a[scores={bse.team_blue=1..}] run function bse:join_blue
execute as @a[tag=bse_owner,scores={bse.start_multi=1..}] run function bse:start_multi
execute unless score #game bse.status matches 1 as @a[tag=bse_owner,scores={bse.stop=1..}] run execute if score #language bse.language matches 0 run tellraw @s {"text":"[BSE] Cannot stop: game has not started.","color":"red"}
execute unless score #game bse.status matches 1 as @a[tag=bse_owner,scores={bse.stop=1..}] run execute if score #language bse.language matches 1 run tellraw @s {"text":"[BSE] No se puede detener: el juego no ha empezado.","color":"red"}
execute if score #game bse.status matches 1 as @a[tag=bse_owner,scores={bse.stop=1..}] run function bse:stop
execute as @a[scores={bse.60=1..}] run function bse:config_60s
execute as @a[scores={bse.90=1..}] run function bse:config_90s
execute as @a[scores={bse.180=1..}] run function bse:config_180s
execute as @a[scores={bse.300=1..}] run function bse:config_300s
execute as @a[scores={bse.dynamic_warn=1..}] run function bse:dynamic_warning
execute as @a[scores={bse.dynamic_accept=1..}] run function bse:config_dynamic
scoreboard players set @a[scores={bse.menu=1..}] bse.menu 0
scoreboard players set @a[scores={bse.config_menu=1..}] bse.config_menu 0
scoreboard players set @a[scores={bse.difficulty_menu=1..}] bse.difficulty_menu 0
scoreboard players set @a[scores={bse.rounds_menu=1..}] bse.rounds_menu 0
scoreboard players set @a[scores={bse.rounds_5=1..}] bse.rounds_5 0
scoreboard players set @a[scores={bse.rounds_10=1..}] bse.rounds_10 0
scoreboard players set @a[scores={bse.rounds_30=1..}] bse.rounds_30 0
scoreboard players set @a[scores={bse.lives_menu=1..}] bse.lives_menu 0
scoreboard players set @a[scores={bse.lives_1=1..}] bse.lives_1 0
scoreboard players set @a[scores={bse.lives_3=1..}] bse.lives_3 0
scoreboard players set @a[scores={bse.lives_5=1..}] bse.lives_5 0
scoreboard players set @a[scores={bse.language_menu=1..}] bse.language_menu 0
scoreboard players set @a[scores={bse.set_english=1..}] bse.set_english 0
scoreboard players set @a[scores={bse.set_spanish=1..}] bse.set_spanish 0
scoreboard players set @a[scores={bse.init_english=1..}] bse.init_english 0
scoreboard players set @a[scores={bse.init_spanish=1..}] bse.init_spanish 0
scoreboard players set @a[scores={bse.dimension_menu=1..}] bse.dimension_menu 0
scoreboard players set @a[scores={bse.tips=1..}] bse.tips 0
scoreboard players set @a[scores={bse.toggle_nether=1..}] bse.toggle_nether 0
scoreboard players set @a[scores={bse.toggle_end=1..}] bse.toggle_end 0
scoreboard players set @a[scores={bse.toggle_overworld=1..}] bse.toggle_overworld 0
scoreboard players set @a[scores={bse.start=1..}] bse.start 0
scoreboard players set @a[scores={bse.solo=1..}] bse.solo 0
scoreboard players set @a[scores={bse.multi=1..}] bse.multi 0
scoreboard players set @a[scores={bse.team_red=1..}] bse.team_red 0
scoreboard players set @a[scores={bse.team_blue=1..}] bse.team_blue 0
scoreboard players set @a[scores={bse.start_multi=1..}] bse.start_multi 0
scoreboard players set @a[scores={bse.stop=1..}] bse.stop 0
scoreboard players set @a[scores={bse.60=1..}] bse.60 0
scoreboard players set @a[scores={bse.90=1..}] bse.90 0
scoreboard players set @a[scores={bse.180=1..}] bse.180 0
scoreboard players set @a[scores={bse.300=1..}] bse.300 0
scoreboard players set @a[scores={bse.dynamic_warn=1..}] bse.dynamic_warn 0
scoreboard players set @a[scores={bse.dynamic_accept=1..}] bse.dynamic_accept 0
execute if score #game bse.status matches 1 run function bse:tick_game

# El primer jugador que entra al mundo queda registrado como creador/administrador del datapack
execute unless entity @a[tag=bse_owner] as @a[limit=1,sort=arbitrary] run tag @s add bse_owner

# Auto menu al entrar
execute as @a[tag=!bse_joined] run function bse:auto_menu
tag @a[tag=!bse_joined] add bse_joined
