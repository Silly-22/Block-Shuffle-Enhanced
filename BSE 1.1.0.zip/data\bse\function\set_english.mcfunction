scoreboard players set #language bse.language 0
tellraw @s [{"text":"[BSE] Language set to English","color":"green"}]
function bse:config_menu
