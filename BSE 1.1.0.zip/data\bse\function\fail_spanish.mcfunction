scoreboard players remove @s bse.lives 1
execute if score @s bse.lives matches 1.. run title @s title {"text":"¡Objetivo Fallado!","color":"gold"}
execute if score @s bse.lives matches 1.. run tellraw @s [{"text":"[BSE] Tienes ","color":"yellow"},{"score":{"name":"@s","objective":"bse.lives"}},{"text":" vidas restantes.","color":"yellow"}]
execute if score @s bse.lives matches ..0 run title @s title {"text":"¡Eliminado!","color":"red"}
execute if score @s bse.lives matches ..0 run tag @s remove bse_playing
# Solo multi: espectador. En solo se mantiene survival.
execute if score @s bse.lives matches ..0 if score #mode bse.config matches 1 run gamemode spectator @s
execute if score @s bse.lives matches ..0 if score #mode bse.config matches 0 run tellraw @s {"text":"[BSE] Eliminado. Los ajustes siguen bloqueados hasta que termine la partida.","color":"gray"}
