tellraw @a [{"text":"[BSE] Game Over! Nobody survived.","color":"red"}]
scoreboard players set #game bse.status 0
execute as @a run function bse:menu
