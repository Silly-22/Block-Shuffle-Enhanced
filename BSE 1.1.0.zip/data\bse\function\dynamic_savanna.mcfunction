# Savanna: acacia family + grass/sand
execute store result score @s bse.rand run random value 1..5
execute if score @s bse.rand matches 1 run scoreboard players set @s bse.target 31
execute if score @s bse.rand matches 2 run scoreboard players set @s bse.target 50
execute if score @s bse.rand matches 3 run scoreboard players set @s bse.target 51
execute if score @s bse.rand matches 4 run scoreboard players set @s bse.target 6
execute if score @s bse.rand matches 5 run scoreboard players set @s bse.target 1
