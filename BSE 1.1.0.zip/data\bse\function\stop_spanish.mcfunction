title @a title {"text":"¡JUEGO TERMINADO!","color":"red","bold":true}
tellraw @a [{"text":"[BSE] ¡JUEGO TERMINADO! Detenido manualmente","color":"red","bold":true}]
playsound minecraft:entity.villager.death master @a ~ ~ ~ 1 0.8
scoreboard players set #game bse.status 0
gamemode creative @a[tag=bse_was_creative]
tag @a remove bse_playing
tag @a remove bse_was_creative
execute as @a run function bse:menu
