# Frozen ocean / ice spikes: ice, packed ice, snow block
execute store result score @s bse.rand run random value 1..3
execute if score @s bse.rand matches 1 run scoreboard players set @s bse.target 11
execute if score @s bse.rand matches 2 run scoreboard players set @s bse.target 38
execute if score @s bse.rand matches 3 run scoreboard players set @s bse.target 10
