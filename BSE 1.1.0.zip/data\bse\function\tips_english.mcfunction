tellraw @s {"text":""}
tellraw @s {"text":"===== BSE 1.1.0 — TIPS =====","color":"aqua","bold":true}
tellraw @s [{"text":"• Reopen menu: ","color":"gray"},{"text":"/trigger bse.menu","color":"aqua","click_event":{"action":"suggest_command","command":"/trigger bse.menu"}},{"text":" or ","color":"gray"},{"text":"/function bse:menu","color":"aqua","click_event":{"action":"suggest_command","command":"/function bse:menu"}}]
tellraw @s [{"text":"• Nether & End are ","color":"gray"},{"text":"disabled by default","color":"red"},{"text":". Enable them manually:","color":"gray"}]
tellraw @s [{"text":"  /function bse:config/nether/enable","color":"white","click_event":{"action":"suggest_command","command":"/function bse:config/nether/enable"}}]
tellraw @s [{"text":"  /function bse:config/end/enable","color":"white","click_event":{"action":"suggest_command","command":"/function bse:config/end/enable"}}]
tellraw @s [{"text":"• Disable again: ","color":"gray"},{"text":"/function bse:config/nether/disable","color":"dark_gray","click_event":{"action":"suggest_command","command":"/function bse:config/nether/disable"}},{"text":" / ","color":"dark_gray"},{"text":"/function bse:config/end/disable","color":"dark_gray","click_event":{"action":"suggest_command","command":"/function bse:config/end/disable"}}]
tellraw @s [{"text":"• Dynamic / Biome mode: ","color":"gray"},{"text":"if objectives look wrong or empty, make sure the dimension you are in is enabled","color":"yellow"},{"text":" (Overworld / Nether / End).","color":"gray"}]
tellraw @s [{"text":"• Dimensions menu: Settings → Dimensions","color":"gray"}]
tellraw @s [{"text":"• If flags look wrong after an update, run ","color":"gray"},{"text":"/reload","color":"yellow"},{"text":" or toggle them once.","color":"gray"}]
tellraw @s {"text":"========================================","color":"dark_gray"}
tellraw @s [{"text":"[← BACK TO SETTINGS]","color":"gray","click_event":{"action":"run_command","command":"/trigger bse.config_menu"}}]
