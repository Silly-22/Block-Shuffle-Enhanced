execute if score #language bse.language matches 0 run tellraw @s {"text":"[BSE] You can't change settings while a game is in progress.","color":"red"}
execute if score #language bse.language matches 1 run tellraw @s {"text":"[BSE] No puedes cambiar los ajustes mientras la partida está en curso.","color":"red"}
return fail
