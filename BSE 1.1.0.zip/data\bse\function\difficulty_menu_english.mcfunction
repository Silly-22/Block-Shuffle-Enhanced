scoreboard players set #await_dyn_time bse.config 0
tellraw @s {"text":""}
tellraw @s {"text":"--- TIME ---","color":"yellow","bold":true}
tellraw @s [{"text":"[⏱ 1m]","color":"red","click_event":{"action":"run_command","command":"/trigger bse.60"}},{"text":"  "},{"text":"[⏱ 1m 30s]","color":"gold","click_event":{"action":"run_command","command":"/trigger bse.90"}},{"text":"  "},{"text":"[⏱ 3m]","color":"green","click_event":{"action":"run_command","command":"/trigger bse.180"}},{"text":"  "},{"text":"[⏱ 5m]","color":"aqua","click_event":{"action":"run_command","command":"/trigger bse.300"}}]
tellraw @s [{"text":"[🌍 DYNAMIC MODE]","color":"light_purple","bold":true,"click_event":{"action":"run_command","command":"/trigger bse.dynamic_accept"},"hover_event":{"action":"show_text","value":"Individual objectives adapted to your biome"}}]
tellraw @s [{"text":"[← BACK TO SETTINGS]","color":"gray","click_event":{"action":"run_command","command":"/trigger bse.config_menu"}}]
tellraw @s {"text":"========================================","color":"dark_gray"}
