tellraw @s {"text":""}
tellraw @s {"text":"===== BSE 1.1.0 — TIPS =====","color":"aqua","bold":true}
tellraw @s [{"text":"• Reabrir menú: ","color":"gray"},{"text":"/trigger bse.menu","color":"aqua","click_event":{"action":"suggest_command","command":"/trigger bse.menu"}},{"text":" o ","color":"gray"},{"text":"/function bse:menu","color":"aqua","click_event":{"action":"suggest_command","command":"/function bse:menu"}}]
tellraw @s [{"text":"• Nether y End vienen ","color":"gray"},{"text":"deshabilitados por defecto","color":"red"},{"text":". Activalos manualmente:","color":"gray"}]
tellraw @s [{"text":"  /function bse:config/nether/enable","color":"white","click_event":{"action":"suggest_command","command":"/function bse:config/nether/enable"}}]
tellraw @s [{"text":"  /function bse:config/end/enable","color":"white","click_event":{"action":"suggest_command","command":"/function bse:config/end/enable"}}]
tellraw @s [{"text":"• Deshabilitar otra vez: ","color":"gray"},{"text":"/function bse:config/nether/disable","color":"dark_gray","click_event":{"action":"suggest_command","command":"/function bse:config/nether/disable"}},{"text":" / ","color":"dark_gray"},{"text":"/function bse:config/end/disable","color":"dark_gray","click_event":{"action":"suggest_command","command":"/function bse:config/end/disable"}}]
tellraw @s [{"text":"• Modo dinámico / bioma: ","color":"gray"},{"text":"si los objetivos fallan o salen vacíos, asegurate de tener habilitada la dimensión en la que estás","color":"yellow"},{"text":" (Overworld / Nether / End).","color":"gray"}]
tellraw @s [{"text":"• Menú de dimensiones: Ajustes → Dimensiones","color":"gray"}]
tellraw @s [{"text":"• Si los flags quedan raros tras una actualización, usá ","color":"gray"},{"text":"/reload","color":"yellow"},{"text":" o cambialos una vez.","color":"gray"}]
tellraw @s {"text":"========================================","color":"dark_gray"}
tellraw @s [{"text":"[← VOLVER A AJUSTES]","color":"gray","click_event":{"action":"run_command","command":"/trigger bse.config_menu"}}]
