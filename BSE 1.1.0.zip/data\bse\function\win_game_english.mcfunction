tellraw @a [{"text":"[BSE] Victory! ","color":"gold"},{"score":{"name":"#round","objective":"bse.round"}},{"text":"/"},{"score":{"name":"#total_rounds","objective":"bse.config"}},{"text":" rounds completed. Winners: ","color":"gold"},{"selector":"@a[tag=bse_playing]"}]
title @a title {"text":"Victory!","color":"gold"}
scoreboard players set #game bse.status 0
gamemode creative @a[tag=bse_was_creative]
tag @a remove bse_playing
tag @a remove bse_was_creative
execute as @a run function bse:menu
