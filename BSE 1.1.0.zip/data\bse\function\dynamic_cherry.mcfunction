# Cherry grove: cherry log + planks/stairs, grass, leaves
execute store result score @s bse.rand run random value 1..5
execute if score @s bse.rand matches 1 run scoreboard players set @s bse.target 34
execute if score @s bse.rand matches 2 run scoreboard players set @s bse.target 52
execute if score @s bse.rand matches 3 run scoreboard players set @s bse.target 53
execute if score @s bse.rand matches 4 run scoreboard players set @s bse.target 6
execute if score @s bse.rand matches 5 run scoreboard players set @s bse.target 5
