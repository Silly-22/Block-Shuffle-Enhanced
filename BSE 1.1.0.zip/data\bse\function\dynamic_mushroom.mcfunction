# Mushroom fields: mycelium-like via dirt/grass/moss
execute store result score @s bse.rand run random value 1..3
execute if score @s bse.rand matches 1 run scoreboard players set @s bse.target 6
execute if score @s bse.rand matches 2 run scoreboard players set @s bse.target 17
execute if score @s bse.rand matches 3 run scoreboard players set @s bse.target 36
