scoreboard players set #round_time bse.config 3600
scoreboard players set #dynamic bse.config 0
tellraw @a [{"text":"[BSE] Difficulty: EASY (3m)","color":"green"}]
function blockshuffle:menu
