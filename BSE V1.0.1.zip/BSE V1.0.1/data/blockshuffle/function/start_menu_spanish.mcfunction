tellraw @s {"text":""}
tellraw @s {"text":"====== SELECCIONAR MODO DE JUEGO ======","color":"aqua","bold":true}
tellraw @s [{"text":"[INICIAR UN JUGADOR]","color":"green","bold":true,"click_event":{"action":"run_command","command":"/trigger bse.solo"},"hover_event":{"action":"show_text","value":"Iniciar juego individual"}}]
tellraw @s [{"text":"[INICIAR MULTIJUGADOR]","color":"gold","bold":true,"click_event":{"action":"run_command","command":"/trigger bse.multi"},"hover_event":{"action":"show_text","value":"Elige equipos Rojo y Azul antes de iniciar"}}]
tellraw @s {"text":"=====================================","color":"dark_gray"}
