scoreboard objectives add bse.timer dummy
scoreboard objectives add bse.max_timer dummy
scoreboard objectives add bse.round dummy
scoreboard objectives add bse.status dummy
scoreboard objectives add bse.found dummy
scoreboard objectives add bse.lives dummy
scoreboard objectives add bse.config dummy
scoreboard objectives add bse.rand dummy
scoreboard objectives add bse.min dummy
scoreboard objectives add bse.sec dummy
scoreboard objectives add bse.sec_total dummy
scoreboard objectives add bse.20 dummy
scoreboard objectives add bse.start trigger
scoreboard objectives add bse.solo trigger
scoreboard objectives add bse.multi trigger
scoreboard objectives add bse.team_red trigger
scoreboard objectives add bse.team_blue trigger
scoreboard objectives add bse.start_multi trigger
scoreboard objectives add bse.stop trigger
scoreboard objectives add bse.menu trigger
scoreboard objectives add bse.60 trigger
scoreboard objectives add bse.90 trigger
scoreboard objectives add bse.180 trigger
scoreboard objectives add bse.300 trigger
scoreboard objectives add bse.dynamic_warn trigger
scoreboard objectives add bse.dynamic_accept trigger
scoreboard objectives add bse.target dummy
scoreboard players set #game bse.status 0
scoreboard players set #round bse.round 0
scoreboard players set #timer bse.timer 0
scoreboard players set #max_timer bse.max_timer 1800
scoreboard players set #round_time bse.config 3600
scoreboard players set #total_rounds bse.config 5
scoreboard players set #20 bse.20 20
scoreboard players set #max_lives bse.lives 1
scoreboard players set #dynamic bse.config 0
scoreboard players set #60 bse.config 60
team add bse_rojo
team modify bse_rojo color red
team add bse_azul
team modify bse_azul color blue
function blockshuffle:setup_blocks
execute if score #language bse.language matches 0 run tellraw @a [{"text":"[BSE] 1.0.1 - Ready!","color":"green"}]
execute if score #language bse.language matches 1 run tellraw @a [{"text":"[BSE] 1.0.1 - ¡Listo!","color":"green"}]

scoreboard objectives add bse.config_menu trigger
scoreboard objectives add bse.difficulty_menu trigger
scoreboard objectives add bse.rounds_menu trigger
scoreboard objectives add bse.rounds_5 trigger
scoreboard objectives add bse.rounds_10 trigger
scoreboard objectives add bse.rounds_30 trigger
scoreboard objectives add bse.lives_menu trigger
scoreboard objectives add bse.lives_1 trigger
scoreboard objectives add bse.lives_3 trigger
scoreboard objectives add bse.lives_5 trigger
scoreboard objectives add bse.language dummy
scoreboard objectives add bse.language_menu trigger
scoreboard objectives add bse.set_english trigger
scoreboard objectives add bse.set_spanish trigger
scoreboard objectives add bse.init_english trigger
scoreboard objectives add bse.init_spanish trigger

gamerule send_command_feedback false
