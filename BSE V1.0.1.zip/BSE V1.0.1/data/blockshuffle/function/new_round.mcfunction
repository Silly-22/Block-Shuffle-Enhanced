scoreboard players set @a[tag=bse_playing] bse.found 0
scoreboard players operation #timer bse.timer = #round_time bse.config
scoreboard players operation #max_timer bse.max_timer = #round_time bse.config
execute if score #dynamic bse.config matches 1 run execute if score #language bse.language matches 0 run function blockshuffle:dynamic_new_round_english
execute if score #dynamic bse.config matches 1 run execute if score #language bse.language matches 1 run function blockshuffle:dynamic_new_round_spanish
execute unless score #dynamic bse.config matches 1 run execute if score #language bse.language matches 0 run function blockshuffle:normal_new_round_english
execute unless score #dynamic bse.config matches 1 run execute if score #language bse.language matches 1 run function blockshuffle:normal_new_round_spanish
