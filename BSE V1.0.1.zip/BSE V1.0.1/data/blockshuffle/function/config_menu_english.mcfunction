tellraw @s {"text":""}
tellraw @s {"text":"--- SETTINGS ---","color":"yellow","bold":true}
tellraw @s [{"text":"[⚙ DIFFICULTY]","color":"yellow","click_event":{"action":"run_command","command":"/trigger bse.difficulty_menu"}}]
tellraw @s [{"text":"[⚙ ROUND SETTINGS]","color":"light_purple","click_event":{"action":"run_command","command":"/trigger bse.rounds_menu"}}]
tellraw @s [{"text":"[♥ PLAYER LIVES: ","color":"red"},{"score":{"name":"#max_lives","objective":"bse.lives"}},{"text":"]","color":"red"},{"text":" ","color":"white"},{"text":"[CHANGE]","color":"gold","click_event":{"action":"run_command","command":"/trigger bse.lives_menu"}}]
tellraw @s [{"text":"[🌐 LANGUAGE]","color":"aqua","click_event":{"action":"run_command","command":"/trigger bse.language_menu"}}]
tellraw @s [{"text":"[← BACK TO MENU]","color":"gray","click_event":{"action":"run_command","command":"/trigger bse.menu"}}]
tellraw @s {"text":"========================================","color":"dark_gray"}
