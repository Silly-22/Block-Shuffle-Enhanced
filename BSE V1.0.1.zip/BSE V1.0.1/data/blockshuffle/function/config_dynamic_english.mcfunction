scoreboard players set #dynamic bse.config 1
scoreboard players set #round_time bse.config 1800
tellraw @a {"text":"[BSE] Difficulty: DYNAMIC MODE (90s, biome objectives)","color":"light_purple"}
function blockshuffle:menu
