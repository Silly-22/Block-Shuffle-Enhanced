tellraw @s {"text":""}
tellraw @s {"text":"⚠ ADVERTENCIA: MODO DINÁMICO (BETA)","color":"red","bold":true}
tellraw @s {"text":"Cada jugador recibirá un objetivo basado en el bioma en el que se encuentre.","color":"yellow"}
tellraw @s {"text":"Esta función está en BETA y puede contener errores o comportamiento inesperado. También puede hacer el juego más fácil y reducir parte del desafío de exploración.","color":"gold"}
tellraw @s [{"text":"[ACTIVAR DE TODAS FORMAS]","color":"green","bold":true,"click_event":{"action":"run_command","command":"/trigger bse.dynamic_accept"}},{"text":"  "},{"text":"[VOLVER A DIFICULTAD]","color":"gray","click_event":{"action":"run_command","command":"/trigger bse.difficulty_menu"}}]
