title @s title {"text":"Dynamic Round","color":"light_purple"}
function blockshuffle:dynamic_show
