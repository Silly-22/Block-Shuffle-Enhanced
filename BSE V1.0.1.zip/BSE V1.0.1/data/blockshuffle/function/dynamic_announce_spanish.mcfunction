title @s title {"text":"Ronda Dinámica","color":"light_purple"}
function blockshuffle:dynamic_show
