tellraw @s {"text":""}
tellraw @s {"text":"====== SELECT GAME MODE ======","color":"aqua","bold":true}
tellraw @s [{"text":"[START SINGLEPLAYER]","color":"green","bold":true,"click_event":{"action":"run_command","command":"/trigger bse.solo"},"hover_event":{"action":"show_text","value":"Start a solo game"}}]
tellraw @s [{"text":"[START MULTIPLAYER]","color":"gold","bold":true,"click_event":{"action":"run_command","command":"/trigger bse.multi"},"hover_event":{"action":"show_text","value":"Choose Red and Blue teams before starting"}}]
tellraw @s {"text":"===========================","color":"dark_gray"}
