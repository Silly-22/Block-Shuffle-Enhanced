tag @a remove bse_playing
tag @a remove bse_was_creative
scoreboard players set @a bse.found 0
execute as @a[gamemode=creative] run tag @s add bse_was_creative
execute if score #mode bse.config matches 0 run tag @a[gamemode=!spectator] add bse_playing
execute if score #mode bse.config matches 1 run tag @a[tag=bse_team_red,gamemode=!spectator] add bse_playing
execute if score #mode bse.config matches 1 run tag @a[tag=bse_team_blue,gamemode=!spectator] add bse_playing
scoreboard players operation @a[tag=bse_playing] bse.lives = #max_lives bse.lives
gamemode survival @a[tag=bse_playing,tag=!bse_was_creative]
scoreboard players set #game bse.status 1
scoreboard players set #round bse.round 1
scoreboard players operation #timer bse.timer = #round_time bse.config
scoreboard players operation #max_timer bse.max_timer = #round_time bse.config
function blockshuffle:new_round
