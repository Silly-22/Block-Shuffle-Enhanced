execute store result score @s bse.rand run random value 16..18
scoreboard players operation @s bse.target = @s bse.rand
