tag @s remove bse_team_red
tag @s add bse_team_blue
team join bse_azul @s
tellraw @s {"text":"[BSE] You joined the Blue Team.","color":"blue"}
