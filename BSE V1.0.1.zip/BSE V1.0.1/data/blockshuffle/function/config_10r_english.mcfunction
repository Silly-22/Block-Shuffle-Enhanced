scoreboard players set #total_rounds bse.config 10
tellraw @a [{"text":"[BSE] Rounds set: 10","color":"gold"}]
function blockshuffle:menu
