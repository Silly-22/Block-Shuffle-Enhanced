scoreboard players set @s bse.found 1
title @s title {"text":"¡Objetivo Completado!","color":"green"}
execute if score #dynamic bse.config matches 1 run title @s subtitle {"text":"Objetivo de bioma completado","color":"green"}
execute unless score #dynamic bse.config matches 1 run title @s subtitle [{"nbt":"pretty","storage":"blockshuffle:game"}]
