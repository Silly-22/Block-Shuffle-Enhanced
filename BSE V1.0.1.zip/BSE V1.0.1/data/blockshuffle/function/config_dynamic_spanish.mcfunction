scoreboard players set #dynamic bse.config 1
scoreboard players set #round_time bse.config 1800
tellraw @a {"text":"[BSE] Dificultad: MODO DINÁMICO (90s, objetivos de bioma)","color":"light_purple"}
function blockshuffle:menu
