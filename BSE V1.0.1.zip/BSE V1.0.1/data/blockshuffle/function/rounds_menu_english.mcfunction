tellraw @s {"text":""}
tellraw @s {"text":"--- ROUND SETTINGS ---","color":"light_purple","bold":true}
tellraw @s [{"text":"[5 ROUNDS]","color":"green","click_event":{"action":"run_command","command":"/trigger bse.rounds_5"}},{"text":"  "},{"text":"[10 ROUNDS]","color":"gold","click_event":{"action":"run_command","command":"/trigger bse.rounds_10"}},{"text":"  "},{"text":"[30 ROUNDS]","color":"red","click_event":{"action":"run_command","command":"/trigger bse.rounds_30"}}]
tellraw @s [{"text":"[← BACK TO SETTINGS]","color":"gray","click_event":{"action":"run_command","command":"/trigger bse.config_menu"}}]
tellraw @s {"text":"========================================","color":"dark_gray"}
