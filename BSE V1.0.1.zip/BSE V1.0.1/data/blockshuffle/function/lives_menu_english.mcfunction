tellraw @s {"text":""}
tellraw @s {"text":"====== PLAYER LIVES ======","color":"red","bold":true}
tellraw @s [{"text":"[♥ 1 LIFE]","color":"red","bold":true,"click_event":{"action":"run_command","command":"/trigger bse.lives_1"}},{"text":"  "},{"text":"[♥♥♥ 3 LIVES]","color":"gold","bold":true,"click_event":{"action":"run_command","command":"/trigger bse.lives_3"}},{"text":"  "},{"text":"[♥♥♥♥♥ 5 LIVES]","color":"light_purple","bold":true,"click_event":{"action":"run_command","command":"/trigger bse.lives_5"}}]
tellraw @s [{"text":"[← BACK TO SETTINGS]","color":"gray","click_event":{"action":"run_command","command":"/trigger bse.config_menu"}}]
tellraw @s {"text":"Each failed round removes one life.","color":"gray"}
tellraw @s {"text":"================================","color":"dark_gray"}
