tellraw @s {"text":""}
tellraw @s {"text":"===== Block Shuffle Enhanced 1.0.1 =====","color":"aqua","bold":true}
tellraw @s [{"text":"[▶ INICIAR JUEGO]","color":"green","bold":true,"click_event":{"action":"run_command","command":"/trigger bse.start"}},{"text":"  "},{"text":"[■ DETENER JUEGO]","color":"red","bold":true,"click_event":{"action":"run_command","command":"/trigger bse.stop"}}]
tellraw @s [{"text":"[⚙ AJUSTES]","color":"yellow","click_event":{"action":"run_command","command":"/trigger bse.config_menu"},"hover_event":{"action":"show_text","value":"Abrir ajustes"}}]
tellraw @s {"text":"========================================","color":"dark_gray"}
