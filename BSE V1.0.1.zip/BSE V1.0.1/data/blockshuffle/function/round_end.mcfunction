execute if score #language bse.language matches 0 run function blockshuffle:round_end_english
execute if score #language bse.language matches 1 run function blockshuffle:round_end_spanish
