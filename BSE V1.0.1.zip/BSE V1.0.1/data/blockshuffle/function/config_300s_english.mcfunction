scoreboard players set #round_time bse.config 6000
scoreboard players set #dynamic bse.config 0
tellraw @a [{"text":"[BSE] Difficulty: VERY EASY (5m)","color":"aqua"}]
function blockshuffle:menu
