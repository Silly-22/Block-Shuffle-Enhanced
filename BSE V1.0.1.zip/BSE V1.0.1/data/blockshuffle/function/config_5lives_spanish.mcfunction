scoreboard players set #max_lives bse.lives 5
tellraw @a {"text":"[BSE] Vidas del jugador establecidas: 5","color":"light_purple"}
function blockshuffle:config_menu
