tag @s remove bse_team_blue
tag @s add bse_team_red
team join bse_rojo @s
tellraw @s {"text":"[BSE] You joined the Red Team.","color":"red"}
