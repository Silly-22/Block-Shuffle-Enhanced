scoreboard players set #max_lives bse.lives 3
tellraw @a {"text":"[BSE] Vidas del jugador establecidas: 3","color":"gold"}
function blockshuffle:config_menu
