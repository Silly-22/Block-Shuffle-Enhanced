title @a title {"text":"GAME OVER!","color":"red","bold":true}
tellraw @a [{"text":"[BSE] GAME OVER! Manually stopped","color":"red","bold":true}]
playsound minecraft:entity.villager.death master @a ~ ~ ~ 1 0.8
scoreboard players set #game bse.status 0
gamemode creative @a[tag=bse_was_creative]
tag @a remove bse_playing
tag @a remove bse_was_creative
execute as @a run function blockshuffle:menu
