tellraw @s {"text":""}
tellraw @s {"text":"====== VIDAS DEL JUGADOR ======","color":"red","bold":true}
tellraw @s [{"text":"[♥ 1 VIDA]","color":"red","bold":true,"click_event":{"action":"run_command","command":"/trigger bse.lives_1"}},{"text":"  "},{"text":"[♥♥♥ 3 VIDAS]","color":"gold","bold":true,"click_event":{"action":"run_command","command":"/trigger bse.lives_3"}},{"text":"  "},{"text":"[♥♥♥♥♥ 5 VIDAS]","color":"light_purple","bold":true,"click_event":{"action":"run_command","command":"/trigger bse.lives_5"}}]
tellraw @s [{"text":"[← VOLVER A AJUSTES]","color":"gray","click_event":{"action":"run_command","command":"/trigger bse.config_menu"}}]
tellraw @s {"text":"Cada ronda fallida elimina una vida.","color":"gray"}
tellraw @s {"text":"================================","color":"dark_gray"}
