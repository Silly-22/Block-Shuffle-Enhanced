execute store result score @s bse.rand run random value 4..6
scoreboard players operation @s bse.target = @s bse.rand
