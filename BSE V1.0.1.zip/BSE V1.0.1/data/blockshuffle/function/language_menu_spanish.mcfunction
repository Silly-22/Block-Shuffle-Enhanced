tellraw @s {"text":""}
tellraw @s {"text":"--- IDIOMA ---","color":"yellow","bold":true}
tellraw @s [{"text":"[🇬🇧 English]","color":"green","click_event":{"action":"run_command","command":"/trigger bse.set_english"}}]
tellraw @s [{"text":"[🇪🇸 Spanish]","color":"green","click_event":{"action":"run_command","command":"/trigger bse.set_spanish"}}]
tellraw @s [{"text":"[← VOLVER A AJUSTES]","color":"gray","click_event":{"action":"run_command","command":"/trigger bse.config_menu"}}]
tellraw @s {"text":"========================================","color":"dark_gray"}
