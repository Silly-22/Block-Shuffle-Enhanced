function blockshuffle:pick_random
function blockshuffle:translate_name
tellraw @a [{"text":"[BSE] [Round ","color":"yellow"},{"score":{"name":"#round","objective":"bse.round"}},{"text":"/"},{"score":{"name":"#total_rounds","objective":"bse.config"}},{"text":"] New Round! "},{"nbt":"pretty","storage":"blockshuffle:game","color":"aqua","bold":true}]
title @a title [{"text":"Round "},{"score":{"name":"#round","objective":"bse.round"}}]
title @a subtitle [{"nbt":"pretty","storage":"blockshuffle:game"}]
