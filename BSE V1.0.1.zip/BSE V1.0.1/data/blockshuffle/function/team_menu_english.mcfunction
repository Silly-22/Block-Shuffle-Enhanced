tellraw @s {"text":""}
tellraw @s {"text":"====== SELECT TEAM ======","color":"aqua","bold":true}
tellraw @s [{"text":"[RED TEAM]","color":"red","bold":true,"click_event":{"action":"run_command","command":"/trigger bse.team_red"}},{"text":"  "},{"text":"[BLUE TEAM]","color":"blue","bold":true,"click_event":{"action":"run_command","command":"/trigger bse.team_blue"}}]
tellraw @s [{"text":"[START MULTIPLAYER]","color":"green","bold":true,"click_event":{"action":"run_command","command":"/trigger bse.start_multi"},"hover_event":{"action":"show_text","value":"Requires at least one player on each team"}}]
tellraw @s [{"text":"[← BACK TO MENU]","color":"yellow","click_event":{"action":"run_command","command":"/trigger bse.menu"}}]
tellraw @s {"text":"Choose a team and press Start when ready.","color":"gray"}
tellraw @s {"text":"=====================","color":"dark_gray"}
