scoreboard players set #round_time bse.config 1200
scoreboard players set #dynamic bse.config 0
tellraw @a [{"text":"[BSE] Dificultad: DIFÍCIL (1m)","color":"red"}]
function blockshuffle:menu
