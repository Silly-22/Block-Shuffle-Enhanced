execute if score #language bse.language matches 0 run function blockshuffle:lives_menu_english
execute if score #language bse.language matches 1 run function blockshuffle:lives_menu_spanish
