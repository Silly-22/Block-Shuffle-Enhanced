scoreboard players set #language bse.language 0
tellraw @s [{"text":"[BSE] Language set to English","color":"green"}]
function blockshuffle:config_menu
