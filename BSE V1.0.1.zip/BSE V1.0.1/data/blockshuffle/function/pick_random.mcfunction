execute store result score #rand bse.rand run random value 0..99
execute store result storage blockshuffle:temp rand int 1 run scoreboard players get #rand bse.rand
function blockshuffle:apply_random with storage blockshuffle:temp
function blockshuffle:filter_difficulty
