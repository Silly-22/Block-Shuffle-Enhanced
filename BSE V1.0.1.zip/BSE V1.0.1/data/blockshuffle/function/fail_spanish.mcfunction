scoreboard players remove @s bse.lives 1
execute if score @s bse.lives matches 1.. run title @s title {"text":"¡Objetivo Fallado!","color":"gold"}
execute if score @s bse.lives matches 1.. run tellraw @s [{"text":"[BSE] Tienes ","color":"yellow"},{"score":{"name":"@s","objective":"bse.lives"}},{"text":" vidas restantes.","color":"yellow"}]
execute if score @s bse.lives matches ..0 run title @s title {"text":"¡Eliminado!","color":"red"}
execute if score @s bse.lives matches ..0 run tag @s remove bse_playing
execute if score @s bse.lives matches ..0 run gamemode spectator @s
