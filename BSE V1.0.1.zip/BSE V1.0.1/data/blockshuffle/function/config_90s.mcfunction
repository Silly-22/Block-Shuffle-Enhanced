execute if score #language bse.language matches 0 run function blockshuffle:config_90s_english
execute if score #language bse.language matches 1 run function blockshuffle:config_90s_spanish
