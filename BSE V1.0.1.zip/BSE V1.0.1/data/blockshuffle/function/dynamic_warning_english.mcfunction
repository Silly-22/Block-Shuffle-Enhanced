tellraw @s {"text":""}
tellraw @s {"text":"⚠ WARNING: DYNAMIC MODE (BETA)","color":"red","bold":true}
tellraw @s {"text":"Each player will receive an objective based on the biome they are in.","color":"yellow"}
tellraw @s {"text":"This feature is in BETA and may contain bugs or unexpected behavior. It may also make the game easier and reduce some of the exploration challenge.","color":"gold"}
tellraw @s [{"text":"[ENABLE ANYWAY]","color":"green","bold":true,"click_event":{"action":"run_command","command":"/trigger bse.dynamic_accept"}},{"text":"  "},{"text":"[BACK TO DIFFICULTY]","color":"gray","click_event":{"action":"run_command","command":"/trigger bse.difficulty_menu"}}]
