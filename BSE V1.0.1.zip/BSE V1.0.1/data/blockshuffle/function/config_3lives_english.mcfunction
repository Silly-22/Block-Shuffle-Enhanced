scoreboard players set #max_lives bse.lives 3
tellraw @a {"text":"[BSE] Player Lives set: 3","color":"gold"}
function blockshuffle:config_menu
