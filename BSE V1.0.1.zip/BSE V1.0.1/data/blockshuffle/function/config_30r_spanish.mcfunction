scoreboard players set #total_rounds bse.config 30
tellraw @a [{"text":"[BSE] Rondas establecidas: 30","color":"red"}]
function blockshuffle:menu
