execute if score #language bse.language matches 0 run function blockshuffle:config_5lives_english
execute if score #language bse.language matches 1 run function blockshuffle:config_5lives_spanish
