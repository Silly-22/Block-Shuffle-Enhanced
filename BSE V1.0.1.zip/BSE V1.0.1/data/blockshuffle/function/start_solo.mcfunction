tag @a remove bse_team_red
tag @a remove bse_team_blue
team leave @a
scoreboard players set #mode bse.config 0
function blockshuffle:start
