execute store result score @s bse.rand run random value 7..9
scoreboard players operation @s bse.target = @s bse.rand
