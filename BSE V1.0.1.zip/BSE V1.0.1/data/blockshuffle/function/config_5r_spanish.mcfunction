scoreboard players set #total_rounds bse.config 5
tellraw @a [{"text":"[BSE] Rondas establecidas: 5","color":"green"}]
function blockshuffle:menu
