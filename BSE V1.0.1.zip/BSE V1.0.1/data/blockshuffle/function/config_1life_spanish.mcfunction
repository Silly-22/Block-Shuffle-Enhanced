scoreboard players set #max_lives bse.lives 1
tellraw @a {"text":"[BSE] Vidas del jugador establecidas: 1","color":"red"}
function blockshuffle:config_menu
