tellraw @s {"text":""}
tellraw @s {"text":"===== Block Shuffle Enhanced 1.0.1 =====","color":"aqua","bold":true}
tellraw @s {"text":"🌐 Select your language before starting; don't worry, you can change the language again in the datapack settings","color":"yellow"}
tellraw @s {"text":""}
tellraw @s [{"text":"[🇪🇸 Spanish]","color":"green","bold":true,"click_event":{"action":"run_command","command":"/trigger bse.init_spanish"}}]
tellraw @s [{"text":"[🇬🇧 English]","color":"green","bold":true,"click_event":{"action":"run_command","command":"/trigger bse.init_english"}}]
