title @s actionbar [{"text":"⏱️ ","color":"red","bold":true},{"score":{"name":"#min","objective":"bse.min"},"color":"red","bold":true},{"text":":","color":"red","bold":true},{"score":{"name":"#sec","objective":"bse.sec"},"color":"red","bold":true}]
playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 2
