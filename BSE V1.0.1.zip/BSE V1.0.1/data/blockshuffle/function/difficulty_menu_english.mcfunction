tellraw @s {"text":""}
tellraw @s {"text":"--- DIFFICULTY ---","color":"yellow","bold":true}
tellraw @s [{"text":"[1m HARD]","color":"red","click_event":{"action":"run_command","command":"/trigger bse.60"}},{"text":"  "},{"text":"[1m 30s NORMAL]","color":"gold","click_event":{"action":"run_command","command":"/trigger bse.90"}}]
tellraw @s [{"text":"[3m EASY]","color":"green","click_event":{"action":"run_command","command":"/trigger bse.180"}},{"text":"  "},{"text":"[5m VERY EASY]","color":"aqua","click_event":{"action":"run_command","command":"/trigger bse.300"}}]
tellraw @s [{"text":"[🌍 DYNAMIC MODE (BETA)]","color":"light_purple","bold":true,"click_event":{"action":"run_command","command":"/trigger bse.dynamic_warn"},"hover_event":{"action":"show_text","value":"Individual objectives adapted to biome. Feature in BETA"}}]
tellraw @s [{"text":"[← BACK TO SETTINGS]","color":"gray","click_event":{"action":"run_command","command":"/trigger bse.config_menu"}}]
tellraw @s {"text":"========================================","color":"dark_gray"}
