scoreboard players set #language bse.language 1
tag @s add bse_language_selected
function blockshuffle:menu_spanish
