execute store result score @s bse.rand run random value 10..12
scoreboard players operation @s bse.target = @s bse.rand
