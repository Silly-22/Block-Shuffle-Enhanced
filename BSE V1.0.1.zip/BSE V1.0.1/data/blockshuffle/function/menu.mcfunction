execute if score #language bse.language matches 0 run function blockshuffle:menu_english
execute if score #language bse.language matches 1 run function blockshuffle:menu_spanish
