scoreboard players set #max_lives bse.lives 1
tellraw @a {"text":"[BSE] Player Lives set: 1","color":"red"}
function blockshuffle:config_menu
