tellraw @s {"text":""}
tellraw @s {"text":"====== SELECCIONAR EQUIPO ======","color":"aqua","bold":true}
tellraw @s [{"text":"[EQUIPO ROJO]","color":"red","bold":true,"click_event":{"action":"run_command","command":"/trigger bse.team_red"}},{"text":"  "},{"text":"[EQUIPO AZUL]","color":"blue","bold":true,"click_event":{"action":"run_command","command":"/trigger bse.team_blue"}}]
tellraw @s [{"text":"[INICIAR MULTIJUGADOR]","color":"green","bold":true,"click_event":{"action":"run_command","command":"/trigger bse.start_multi"},"hover_event":{"action":"show_text","value":"Requiere al menos un jugador en cada equipo"}}]
tellraw @s [{"text":"[← VOLVER AL MENÚ]","color":"yellow","click_event":{"action":"run_command","command":"/trigger bse.menu"}}]
tellraw @s {"text":"Elige un equipo y presiona Iniciar cuando estés listo.","color":"gray"}
tellraw @s {"text":"==============================","color":"dark_gray"}
