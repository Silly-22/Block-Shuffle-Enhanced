scoreboard players set #round_time bse.config 1800
scoreboard players set #dynamic bse.config 0
tellraw @a [{"text":"[BSE] Dificultad: NORMAL (1m 30s)","color":"gold"}]
function blockshuffle:menu
