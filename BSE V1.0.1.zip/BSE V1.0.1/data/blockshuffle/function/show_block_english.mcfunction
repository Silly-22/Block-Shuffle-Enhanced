execute if score #dynamic bse.config matches 1 run function blockshuffle:dynamic_show
execute unless score #dynamic bse.config matches 1 run function blockshuffle:show_timer_color
