scoreboard players set #game bse.status 1
scoreboard players add #round bse.round 1
function blockshuffle:new_round
