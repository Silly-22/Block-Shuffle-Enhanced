scoreboard players remove #timer bse.timer 1
execute if score #timer bse.timer matches ..0 run scoreboard players set #timer bse.timer 0
scoreboard players operation #sec_total bse.sec_total = #timer bse.timer
scoreboard players operation #sec_total bse.sec_total /= #20 bse.20
scoreboard players operation #min bse.min = #sec_total bse.sec_total
scoreboard players operation #min bse.min /= #60 bse.config
scoreboard players operation #sec bse.sec = #sec_total bse.sec_total
scoreboard players operation #sec bse.sec %= #60 bse.config
execute if score #dynamic bse.config matches 1 as @a[tag=bse_playing,scores={bse.found=0}] at @s run function blockshuffle:dynamic_check
execute unless score #dynamic bse.config matches 1 as @a[tag=bse_playing,scores={bse.found=0}] at @s run function blockshuffle:check_player with storage blockshuffle:game
execute as @a[tag=bse_playing] run function blockshuffle:show_block
execute if score #timer bse.timer matches 0 run return run function blockshuffle:round_end
execute unless entity @a[tag=bse_playing,scores={bse.found=0}] run function blockshuffle:round_end
