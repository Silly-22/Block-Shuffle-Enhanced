execute store result score @s bse.rand run random value 1..3
execute if score @s bse.rand matches 1 run scoreboard players set @s bse.target 1
execute if score @s bse.rand matches 2 run scoreboard players set @s bse.target 2
execute if score @s bse.rand matches 3 run scoreboard players set @s bse.target 3
