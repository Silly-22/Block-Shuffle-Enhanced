execute if score #language bse.language matches 0 run function blockshuffle:dynamic_show_english
execute if score #language bse.language matches 1 run function blockshuffle:dynamic_show_spanish
