tellraw @s {"text":""}
tellraw @s {"text":"--- DIFICULTAD ---","color":"yellow","bold":true}
tellraw @s [{"text":"[1m DIFÍCIL]","color":"red","click_event":{"action":"run_command","command":"/trigger bse.60"}},{"text":"  "},{"text":"[1m 30s NORMAL]","color":"gold","click_event":{"action":"run_command","command":"/trigger bse.90"}}]
tellraw @s [{"text":"[3m FÁCIL]","color":"green","click_event":{"action":"run_command","command":"/trigger bse.180"}},{"text":"  "},{"text":"[5m MUY FÁCIL]","color":"aqua","click_event":{"action":"run_command","command":"/trigger bse.300"}}]
tellraw @s [{"text":"[🌍 MODO DINÁMICO (BETA)]","color":"light_purple","bold":true,"click_event":{"action":"run_command","command":"/trigger bse.dynamic_warn"},"hover_event":{"action":"show_text","value":"Objetivos individuales adaptados al bioma. Función en BETA"}}]
tellraw @s [{"text":"[← VOLVER A AJUSTES]","color":"gray","click_event":{"action":"run_command","command":"/trigger bse.config_menu"}}]
tellraw @s {"text":"========================================","color":"dark_gray"}
