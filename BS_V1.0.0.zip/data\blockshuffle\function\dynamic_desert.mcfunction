execute store result score @s bs.rand run random value 1..3
execute if score @s bs.rand matches 1 run scoreboard players set @s bs.target 1
execute if score @s bs.rand matches 2 run scoreboard players set @s bs.target 2
execute if score @s bs.rand matches 3 run scoreboard players set @s bs.target 3
