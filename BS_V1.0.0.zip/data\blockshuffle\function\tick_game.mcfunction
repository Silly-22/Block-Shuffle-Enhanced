scoreboard players remove #timer bs.timer 1
execute if score #timer bs.timer matches ..0 run scoreboard players set #timer bs.timer 0
scoreboard players operation #sec_total bs.sec_total = #timer bs.timer
scoreboard players operation #sec_total bs.sec_total /= #20 bs.20
scoreboard players operation #min bs.min = #sec_total bs.sec_total
scoreboard players operation #min bs.min /= #60 bs.config
scoreboard players operation #sec bs.sec = #sec_total bs.sec_total
scoreboard players operation #sec bs.sec %= #60 bs.config
bossbar set blockshuffle:timer players @a
execute store result bossbar blockshuffle:timer value run scoreboard players get #timer bs.timer
execute store result bossbar blockshuffle:timer max run scoreboard players get #max_timer bs.timer
execute if score #dynamic bs.config matches 1 as @a[tag=bs_playing,scores={bs.found=0}] at @s run function blockshuffle:dynamic_check
execute unless score #dynamic bs.config matches 1 as @a[tag=bs_playing,scores={bs.found=0}] at @s run function blockshuffle:check_player with storage blockshuffle:game
execute as @a[tag=bs_playing] run function blockshuffle:show_block
execute if score #timer bs.timer matches 0 run return run function blockshuffle:round_end
execute unless entity @a[tag=bs_playing,scores={bs.found=0}] run function blockshuffle:round_end
