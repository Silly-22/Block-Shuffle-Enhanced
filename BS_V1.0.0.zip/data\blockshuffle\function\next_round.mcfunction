scoreboard players set #game bs.status 1
scoreboard players add #round bs.round 1
function blockshuffle:new_round
