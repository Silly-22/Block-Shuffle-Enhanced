scoreboard players remove @s bs.lives 1
execute if score @s bs.lives matches 1.. run title @s title {"text":"Vida perdida","color":"gold"}
execute if score @s bs.lives matches 1.. run tellraw @s [{"text":"[Block Shuffle] Te quedan ","color":"yellow"},{"score":{"name":"@s","objective":"bs.lives"}},{"text":" vidas.","color":"yellow"}]
execute if score @s bs.lives matches ..0 run title @s title {"text":"Eliminado","color":"red"}
execute if score @s bs.lives matches ..0 run tag @s remove bs_playing
execute if score @s bs.lives matches ..0 run gamemode spectator @s
