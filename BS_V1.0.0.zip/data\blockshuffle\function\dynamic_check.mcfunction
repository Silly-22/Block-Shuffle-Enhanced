# Check the block occupied by the player, then the block below their feet.
execute positioned ~ ~ ~ run function blockshuffle:dynamic_check_at
execute positioned ~ ~-0.01 ~ run function blockshuffle:dynamic_check_at
execute positioned ~ ~-1 ~ run function blockshuffle:dynamic_check_at
