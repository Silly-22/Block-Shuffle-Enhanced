scoreboard players set #round_time bs.config 1200
scoreboard players set #dynamic bs.config 0
tellraw @a [{"text":"Dificultad: DIFICIL (1m)","color":"red"}]
function blockshuffle:menu
