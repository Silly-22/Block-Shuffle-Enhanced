scoreboard players set @s bs.found 1
title @s title {"text":"¡Encontrado!","color":"green"}
execute if score #dynamic bs.config matches 1 run title @s subtitle {"text":"Objetivo del bioma encontrado","color":"green"}
execute unless score #dynamic bs.config matches 1 run title @s subtitle [{"nbt":"pretty","storage":"blockshuffle:game"}]
