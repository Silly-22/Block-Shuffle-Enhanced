scoreboard players set @a[tag=bs_playing] bs.found 0
scoreboard players operation #timer bs.timer = #round_time bs.config
scoreboard players operation #max_timer bs.timer = #round_time bs.config
execute if score #dynamic bs.config matches 1 run function blockshuffle:dynamic_new_round
execute unless score #dynamic bs.config matches 1 run function blockshuffle:normal_new_round
