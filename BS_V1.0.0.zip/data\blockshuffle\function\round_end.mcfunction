scoreboard players set #game bs.status 2
execute as @a[tag=bs_playing,scores={bs.found=0}] at @s run function blockshuffle:fail
execute unless entity @a[tag=bs_playing] run return run function blockshuffle:game_over
execute if score #round bs.round >= #total_rounds bs.config run return run function blockshuffle:win_game
tellraw @a [{"text":"¡Ronda terminada! Siguiente en 3s...","color":"green"}]
schedule function blockshuffle:next_round 3s
