tag @a remove bs_team_red
tag @a remove bs_team_blue
team leave @a
scoreboard players set #mode bs.config 0
function blockshuffle:start
