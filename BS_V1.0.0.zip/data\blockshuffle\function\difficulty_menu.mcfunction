tellraw @s {"text":""}
tellraw @s {"text":"--- CONFIGURAR DIFICULTAD ---","color":"yellow","bold":true}
tellraw @s [{"text":"[1m DIFICIL]","color":"red","click_event":{"action":"run_command","command":"/trigger bs.60"}},{"text":"  "},{"text":"[1m 30s NORMAL]","color":"gold","click_event":{"action":"run_command","command":"/trigger bs.90"}}]
tellraw @s [{"text":"[3m FACIL]","color":"green","click_event":{"action":"run_command","command":"/trigger bs.180"}},{"text":"  "},{"text":"[5m MUY FACIL]","color":"aqua","click_event":{"action":"run_command","command":"/trigger bs.300"}}]
tellraw @s [{"text":"[🌍 DINAMICA (BETA)]","color":"light_purple","bold":true,"click_event":{"action":"run_command","command":"/trigger bs.dynamic_warn"},"hover_event":{"action":"show_text","value":"Objetivos individuales adaptados al bioma. Funcion en BETA"}}]
tellraw @s [{"text":"[← VOLVER A AJUSTES]","color":"gray","click_event":{"action":"run_command","command":"/trigger bs.config_menu"}}]
tellraw @s {"text":"========================================","color":"dark_gray"}
