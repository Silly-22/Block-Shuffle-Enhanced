tag @a remove bs_playing
tag @a remove bs_was_creative
scoreboard players set @a bs.found 0
execute as @a[gamemode=creative] run tag @s add bs_was_creative
execute if score #mode bs.config matches 0 run tag @a[gamemode=!spectator] add bs_playing
execute if score #mode bs.config matches 1 run tag @a[tag=bs_team_red,gamemode=!spectator] add bs_playing
execute if score #mode bs.config matches 1 run tag @a[tag=bs_team_blue,gamemode=!spectator] add bs_playing
scoreboard players operation @a[tag=bs_playing] bs.lives = #max_lives bs.lives
gamemode survival @a[tag=bs_playing,tag=!bs_was_creative]
scoreboard players set #game bs.status 1
scoreboard players set #round bs.round 1
scoreboard players operation #timer bs.timer = #round_time bs.config
scoreboard players operation #max_timer bs.timer = #round_time bs.config
bossbar set blockshuffle:timer visible true
function blockshuffle:new_round
