function blockshuffle:pick_random
function blockshuffle:translate_name
tellraw @a [{"text":"[Ronda ","color":"yellow"},{"score":{"name":"#round","objective":"bs.round"}},{"text":"/"},{"score":{"name":"#total_rounds","objective":"bs.config"}},{"text":"] Nuevo: "},{"nbt":"pretty","storage":"blockshuffle:game","color":"aqua","bold":true}]
title @a title [{"text":"Ronda "},{"score":{"name":"#round","objective":"bs.round"}}]
title @a subtitle [{"nbt":"pretty","storage":"blockshuffle:game"}]
