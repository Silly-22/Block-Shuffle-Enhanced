execute store result score @s bs.rand run random value 4..6
scoreboard players operation @s bs.target = @s bs.rand
