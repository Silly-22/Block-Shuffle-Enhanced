title @a title {"text":"JUEGO TERMINADO!","color":"red","bold":true}
tellraw @a [{"text":"[Block Shuffle] JUEGO TERMINADO! Detenido manualmente","color":"red","bold":true}]
playsound minecraft:entity.villager.death master @a ~ ~ ~ 1 0.8
scoreboard players set #game bs.status 0
bossbar set blockshuffle:timer visible false
gamemode creative @a[tag=bs_was_creative]
tag @a remove bs_playing
tag @a remove bs_was_creative
execute as @a run function blockshuffle:menu
