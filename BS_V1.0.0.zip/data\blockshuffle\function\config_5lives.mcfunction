scoreboard players set #max_lives bs.lives 5
tellraw @a {"text":"[Block Shuffle] Vidas configuradas: 5","color":"light_purple"}
function blockshuffle:config_menu
