execute store result score @s bs.rand run random value 10..12
scoreboard players operation @s bs.target = @s bs.rand
