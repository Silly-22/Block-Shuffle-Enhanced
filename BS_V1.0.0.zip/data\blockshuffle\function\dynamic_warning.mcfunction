tellraw @s {"text":""}
tellraw @s {"text":"⚠ ADVERTENCIA: DIFICULTAD DINAMICA (BETA)","color":"red","bold":true}
tellraw @s {"text":"Cada jugador recibira un objetivo segun el bioma donde este.","color":"yellow"}
tellraw @s {"text":"Esta funcion esta en fase BETA y puede contener bastantes errores o comportamientos inesperados. Tambien puede hacer la partida mas facil y reducir parte del reto de exploracion.","color":"gold"}
tellraw @s [{"text":"[ACTIVAR DE TODOS MODOS]","color":"green","bold":true,"click_event":{"action":"run_command","command":"/trigger bs.dynamic_accept"}},{"text":"  "},{"text":"[VOLVER A DIFICULTADES]","color":"gray","click_event":{"action":"run_command","command":"/trigger bs.difficulty_menu"}}]
