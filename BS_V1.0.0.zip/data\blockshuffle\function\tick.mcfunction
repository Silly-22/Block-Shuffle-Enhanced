scoreboard players enable @a bs.start
scoreboard players enable @a bs.solo
scoreboard players enable @a bs.multi
scoreboard players enable @a bs.team_red
scoreboard players enable @a bs.team_blue
scoreboard players enable @a bs.start_multi
scoreboard players enable @a bs.stop
scoreboard players enable @a bs.menu
scoreboard players enable @a bs.config_menu
scoreboard players enable @a bs.difficulty_menu
scoreboard players enable @a bs.rounds_menu
scoreboard players enable @a bs.rounds_5
scoreboard players enable @a bs.rounds_10
scoreboard players enable @a bs.rounds_30
scoreboard players enable @a bs.lives_menu
scoreboard players enable @a bs.lives_1
scoreboard players enable @a bs.lives_3
scoreboard players enable @a bs.lives_5
scoreboard players enable @a bs.60
scoreboard players enable @a bs.90
scoreboard players enable @a bs.180
scoreboard players enable @a bs.300
scoreboard players enable @a bs.dynamic_warn
scoreboard players enable @a bs.dynamic_accept
execute as @a[scores={bs.menu=1..}] run function blockshuffle:menu
execute as @a[scores={bs.config_menu=1..}] run function blockshuffle:config_menu
execute as @a[scores={bs.difficulty_menu=1..}] run function blockshuffle:difficulty_menu
execute as @a[scores={bs.rounds_menu=1..}] run function blockshuffle:rounds_menu
execute as @a[scores={bs.rounds_5=1..}] run function blockshuffle:config_5r
execute as @a[scores={bs.rounds_10=1..}] run function blockshuffle:config_10r
execute as @a[scores={bs.rounds_30=1..}] run function blockshuffle:config_30r
execute as @a[scores={bs.lives_menu=1..}] run function blockshuffle:lives_menu
execute as @a[scores={bs.lives_1=1..}] run function blockshuffle:config_1life
execute as @a[scores={bs.lives_3=1..}] run function blockshuffle:config_3lives
execute as @a[scores={bs.lives_5=1..}] run function blockshuffle:config_5lives
# Avisos animados para jugadores que no son el creador
execute as @a[tag=!bs_owner,scores={bs.start=1..}] run function blockshuffle:deny_start
execute as @a[tag=!bs_owner,scores={bs.solo=1..}] run function blockshuffle:deny_start
execute as @a[tag=!bs_owner,scores={bs.multi=1..}] run function blockshuffle:deny_start
execute as @a[tag=!bs_owner,scores={bs.start_multi=1..}] run function blockshuffle:deny_start
execute as @a[tag=!bs_owner,scores={bs.stop=1..}] run function blockshuffle:deny_stop

execute as @a[tag=bs_owner,scores={bs.start=1..}] run function blockshuffle:start_menu
execute as @a[tag=bs_owner,scores={bs.solo=1..}] run function blockshuffle:start_solo
execute as @a[tag=bs_owner,scores={bs.multi=1..}] run function blockshuffle:team_menu
execute as @a[scores={bs.team_red=1..}] run function blockshuffle:join_red
execute as @a[scores={bs.team_blue=1..}] run function blockshuffle:join_blue
execute as @a[tag=bs_owner,scores={bs.start_multi=1..}] run function blockshuffle:start_multi
execute unless score #game bs.status matches 1 as @a[tag=bs_owner,scores={bs.stop=1..}] run tellraw @s {"text":"[Block Shuffle] No se puede detener: el juego no ha empezado.","color":"red"}
execute if score #game bs.status matches 1 as @a[tag=bs_owner,scores={bs.stop=1..}] run function blockshuffle:stop
execute as @a[scores={bs.60=1..}] run function blockshuffle:config_60s
execute as @a[scores={bs.90=1..}] run function blockshuffle:config_90s
execute as @a[scores={bs.180=1..}] run function blockshuffle:config_180s
execute as @a[scores={bs.300=1..}] run function blockshuffle:config_300s
execute as @a[scores={bs.dynamic_warn=1..}] run function blockshuffle:dynamic_warning
execute as @a[scores={bs.dynamic_accept=1..}] run function blockshuffle:config_dynamic
scoreboard players set @a[scores={bs.menu=1..}] bs.menu 0
scoreboard players set @a[scores={bs.config_menu=1..}] bs.config_menu 0
scoreboard players set @a[scores={bs.difficulty_menu=1..}] bs.difficulty_menu 0
scoreboard players set @a[scores={bs.rounds_menu=1..}] bs.rounds_menu 0
scoreboard players set @a[scores={bs.rounds_5=1..}] bs.rounds_5 0
scoreboard players set @a[scores={bs.rounds_10=1..}] bs.rounds_10 0
scoreboard players set @a[scores={bs.rounds_30=1..}] bs.rounds_30 0
scoreboard players set @a[scores={bs.lives_menu=1..}] bs.lives_menu 0
scoreboard players set @a[scores={bs.lives_1=1..}] bs.lives_1 0
scoreboard players set @a[scores={bs.lives_3=1..}] bs.lives_3 0
scoreboard players set @a[scores={bs.lives_5=1..}] bs.lives_5 0
scoreboard players set @a[scores={bs.start=1..}] bs.start 0
scoreboard players set @a[scores={bs.solo=1..}] bs.solo 0
scoreboard players set @a[scores={bs.multi=1..}] bs.multi 0
scoreboard players set @a[scores={bs.team_red=1..}] bs.team_red 0
scoreboard players set @a[scores={bs.team_blue=1..}] bs.team_blue 0
scoreboard players set @a[scores={bs.start_multi=1..}] bs.start_multi 0
scoreboard players set @a[scores={bs.stop=1..}] bs.stop 0
scoreboard players set @a[scores={bs.60=1..}] bs.60 0
scoreboard players set @a[scores={bs.90=1..}] bs.90 0
scoreboard players set @a[scores={bs.180=1..}] bs.180 0
scoreboard players set @a[scores={bs.300=1..}] bs.300 0
scoreboard players set @a[scores={bs.dynamic_warn=1..}] bs.dynamic_warn 0
scoreboard players set @a[scores={bs.dynamic_accept=1..}] bs.dynamic_accept 0
execute if score #game bs.status matches 1 run function blockshuffle:tick_game

# El primer jugador que entra al mundo queda registrado como creador/administrador del datapack
execute unless entity @a[tag=bs_owner] as @a[limit=1,sort=arbitrary] run tag @s add bs_owner

# Auto menu al entrar
execute as @a[tag=!bs_joined] run function blockshuffle:menu
tag @a[tag=!bs_joined] add bs_joined
