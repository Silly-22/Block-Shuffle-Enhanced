tellraw @s {"text":""}
tellraw @s {"text":"========== BLOCK SHUFFLE 1.0.0 ==========","color":"aqua","bold":true}
tellraw @s [{"text":"[▶ INICIAR JUEGO]","color":"green","bold":true,"click_event":{"action":"run_command","command":"/trigger bs.start"}},{"text":"  "},{"text":"[■ DETENER]","color":"red","bold":true,"click_event":{"action":"run_command","command":"/trigger bs.stop"}}]
tellraw @s [{"text":"[⚙ AJUSTES]","color":"yellow","click_event":{"action":"run_command","command":"/trigger bs.config_menu"},"hover_event":{"action":"show_text","value":"Configurar dificultad y rondas"}}]
tellraw @s {"text":"========================================","color":"dark_gray"}
