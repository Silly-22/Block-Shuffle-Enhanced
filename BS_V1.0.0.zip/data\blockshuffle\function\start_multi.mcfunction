execute unless entity @a[tag=bs_team_red] run tellraw @s {"text":"Falta al menos un jugador en el Equipo Rojo.","color":"red"}
execute unless entity @a[tag=bs_team_blue] run tellraw @s {"text":"Falta al menos un jugador en el Equipo Azul.","color":"red"}
execute if entity @a[tag=bs_team_red] if entity @a[tag=bs_team_blue] run scoreboard players set #mode bs.config 1
execute if entity @a[tag=bs_team_red] if entity @a[tag=bs_team_blue] run function blockshuffle:start
