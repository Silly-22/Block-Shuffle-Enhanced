tellraw @s {"text":""}
tellraw @s {"text":"====== EQUIPOS ======","color":"aqua","bold":true}
tellraw @s [{"text":"[EQUIPO ROJO]","color":"red","bold":true,"click_event":{"action":"run_command","command":"/trigger bs.team_red"}},{"text":"  "},{"text":"[EQUIPO AZUL]","color":"blue","bold":true,"click_event":{"action":"run_command","command":"/trigger bs.team_blue"}}]
tellraw @s [{"text":"[COMENZAR MULTIJUGADOR]","color":"green","bold":true,"click_event":{"action":"run_command","command":"/trigger bs.start_multi"},"hover_event":{"action":"show_text","value":"Requiere al menos un jugador en cada equipo"}}]
tellraw @s [{"text":"[← VOLVER AL MENU]","color":"yellow","click_event":{"action":"run_command","command":"/trigger bs.menu"}}]
tellraw @s {"text":"Elige un equipo y pulsa Comenzar cuando esten listos.","color":"gray"}
tellraw @s {"text":"=====================","color":"dark_gray"}
