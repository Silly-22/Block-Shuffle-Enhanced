scoreboard players set #max_lives bs.lives 3
tellraw @a {"text":"[Block Shuffle] Vidas configuradas: 3","color":"gold"}
function blockshuffle:config_menu
