tellraw @s {"text":""}
tellraw @s {"text":"====== MODO DE JUEGO ======","color":"aqua","bold":true}
tellraw @s [{"text":"[INICIAR EN SOLITARIO]","color":"green","bold":true,"click_event":{"action":"run_command","command":"/trigger bs.solo"},"hover_event":{"action":"show_text","value":"Inicia una partida individual"}}]
tellraw @s [{"text":"[INICIAR EN MULTIJUGADOR]","color":"gold","bold":true,"click_event":{"action":"run_command","command":"/trigger bs.multi"},"hover_event":{"action":"show_text","value":"Elegir equipos Rojo y Azul antes de comenzar"}}]
tellraw @s {"text":"===========================","color":"dark_gray"}
