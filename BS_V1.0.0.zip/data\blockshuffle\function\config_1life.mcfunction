scoreboard players set #max_lives bs.lives 1
tellraw @a {"text":"[Block Shuffle] Vidas configuradas: 1","color":"red"}
function blockshuffle:config_menu
