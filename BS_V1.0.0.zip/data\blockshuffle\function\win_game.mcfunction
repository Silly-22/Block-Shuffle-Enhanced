tellraw @a [{"text":"Victoria! ","color":"gold"},{"score":{"name":"#round","objective":"bs.round"}},{"text":"/"},{"score":{"name":"#total_rounds","objective":"bs.config"}},{"text":" rondas completadas. Ganadores: ","color":"gold"},{"selector":"@a[tag=bs_playing]"}]
title @a title {"text":"¡Victoria!","color":"gold"}
scoreboard players set #game bs.status 0
bossbar set blockshuffle:timer visible false
gamemode creative @a[tag=bs_was_creative]
tag @a remove bs_playing
tag @a remove bs_was_creative
execute as @a run function blockshuffle:menu
