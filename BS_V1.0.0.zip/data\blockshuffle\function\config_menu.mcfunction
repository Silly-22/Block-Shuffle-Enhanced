tellraw @s {"text":""}
tellraw @s {"text":"--- AJUSTES ---","color":"yellow","bold":true}
tellraw @s [{"text":"[⚙ CONFIGURAR DIFICULTAD]","color":"yellow","click_event":{"action":"run_command","command":"/trigger bs.difficulty_menu"}}]
tellraw @s [{"text":"[⚙ CONFIGURAR RONDAS]","color":"light_purple","click_event":{"action":"run_command","command":"/trigger bs.rounds_menu"}}]
tellraw @s [{"text":"[♥ AJUSTAR VIDAS: ","color":"red"},{"score":{"name":"#max_lives","objective":"bs.lives"}},{"text":"]","color":"red"},{"text":" ","color":"white"},{"text":"[CAMBIAR]","color":"gold","click_event":{"action":"run_command","command":"/trigger bs.lives_menu"}}]
tellraw @s [{"text":"[← VOLVER AL MENU]","color":"gray","click_event":{"action":"run_command","command":"/trigger bs.menu"}}]
tellraw @s {"text":"========================================","color":"dark_gray"}
