$data modify storage blockshuffle:game target set from storage blockshuffle:blocks Blocks[$(rand)]
