# This function receives storage blockshuffle:game, which contains target.
# The guard prevents detecting the same target twice in one tick.
$execute unless score @s bs.found matches 1 if block ~ ~ ~ $(target) run function blockshuffle:success
