execute store result score @s bs.rand run random value 16..18
scoreboard players operation @s bs.target = @s bs.rand
