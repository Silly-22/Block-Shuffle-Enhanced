tellraw @s {"text":""}
tellraw @s {"text":"--- CONFIGURAR RONDAS ---","color":"light_purple","bold":true}
tellraw @s [{"text":"[5 RONDAS]","color":"green","click_event":{"action":"run_command","command":"/trigger bs.rounds_5"}},{"text":"  "},{"text":"[10 RONDAS]","color":"gold","click_event":{"action":"run_command","command":"/trigger bs.rounds_10"}},{"text":"  "},{"text":"[30 RONDAS]","color":"red","click_event":{"action":"run_command","command":"/trigger bs.rounds_30"}}]
tellraw @s [{"text":"[← VOLVER A AJUSTES]","color":"gray","click_event":{"action":"run_command","command":"/trigger bs.config_menu"}}]
tellraw @s {"text":"========================================","color":"dark_gray"}
