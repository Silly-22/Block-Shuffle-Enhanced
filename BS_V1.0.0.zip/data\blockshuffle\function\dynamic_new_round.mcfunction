execute as @a[tag=bs_playing] at @s run function blockshuffle:dynamic_assign
tellraw @a {"text":"[Block Shuffle] Ronda dinamica: cada jugador tiene un objetivo segun su bioma.","color":"light_purple"}
execute as @a[tag=bs_playing] run function blockshuffle:dynamic_announce
