tag @s remove bs_team_red
tag @s add bs_team_blue
team join bs_azul @s
tellraw @s {"text":"Te uniste al Equipo Azul.","color":"blue"}
