scoreboard players set #round_time bs.config 1800
scoreboard players set #dynamic bs.config 0
tellraw @a [{"text":"Dificultad: NORMAL (1m 30s)","color":"gold"}]
function blockshuffle:menu
