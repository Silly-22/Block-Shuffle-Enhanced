scoreboard players set #total_rounds bs.config 10
tellraw @a [{"text":"Rondas configuradas: 10","color":"gold"}]
function blockshuffle:menu
