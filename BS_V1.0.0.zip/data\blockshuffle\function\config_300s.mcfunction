scoreboard players set #round_time bs.config 6000
scoreboard players set #dynamic bs.config 0
tellraw @a [{"text":"Dificultad: MUY FACIL (5m)","color":"aqua"}]
function blockshuffle:menu
