execute store result score @s bs.rand run random value 13..15
scoreboard players operation @s bs.target = @s bs.rand
