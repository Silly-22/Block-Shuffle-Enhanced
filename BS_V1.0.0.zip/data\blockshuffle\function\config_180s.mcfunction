scoreboard players set #round_time bs.config 3600
scoreboard players set #dynamic bs.config 0
tellraw @a [{"text":"Dificultad: FACIL (3m)","color":"green"}]
function blockshuffle:menu
