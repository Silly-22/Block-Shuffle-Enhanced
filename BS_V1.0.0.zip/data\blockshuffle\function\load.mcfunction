scoreboard objectives add bs.timer dummy
scoreboard objectives add bs.round dummy
scoreboard objectives add bs.status dummy
scoreboard objectives add bs.found dummy
scoreboard objectives add bs.lives dummy
scoreboard objectives add bs.config dummy
scoreboard objectives add bs.rand dummy
scoreboard objectives add bs.min dummy
scoreboard objectives add bs.sec dummy
scoreboard objectives add bs.sec_total dummy
scoreboard objectives add bs.20 dummy
scoreboard objectives add bs.start trigger
scoreboard objectives add bs.solo trigger
scoreboard objectives add bs.multi trigger
scoreboard objectives add bs.team_red trigger
scoreboard objectives add bs.team_blue trigger
scoreboard objectives add bs.start_multi trigger
scoreboard objectives add bs.stop trigger
scoreboard objectives add bs.menu trigger
scoreboard objectives add bs.60 trigger
scoreboard objectives add bs.90 trigger
scoreboard objectives add bs.180 trigger
scoreboard objectives add bs.300 trigger
scoreboard objectives add bs.dynamic_warn trigger
scoreboard objectives add bs.dynamic_accept trigger
scoreboard objectives add bs.target dummy
scoreboard players set #game bs.status 0
scoreboard players set #round bs.round 0
scoreboard players set #timer bs.timer 0
scoreboard players set #max_timer bs.timer 1800
scoreboard players set #round_time bs.config 3600
scoreboard players set #total_rounds bs.config 5
scoreboard players set #20 bs.20 20
scoreboard players set #max_lives bs.lives 1
scoreboard players set #dynamic bs.config 0
scoreboard players set #60 bs.config 60
bossbar add blockshuffle:timer {"text":"Block Shuffle"}
bossbar set blockshuffle:timer visible false
team add bs_rojo
team modify bs_rojo color red
team add bs_azul
team modify bs_azul color blue
function blockshuffle:setup_blocks
tellraw @a [{"text":"[Block Shuffle] 1.0.0 - Listo!","color":"green"}]

scoreboard objectives add bs.config_menu trigger
scoreboard objectives add bs.difficulty_menu trigger
scoreboard objectives add bs.rounds_menu trigger
scoreboard objectives add bs.rounds_5 trigger
scoreboard objectives add bs.rounds_10 trigger
scoreboard objectives add bs.rounds_30 trigger
scoreboard objectives add bs.lives_menu trigger
scoreboard objectives add bs.lives_1 trigger
scoreboard objectives add bs.lives_3 trigger
scoreboard objectives add bs.lives_5 trigger

gamerule send_command_feedback false
