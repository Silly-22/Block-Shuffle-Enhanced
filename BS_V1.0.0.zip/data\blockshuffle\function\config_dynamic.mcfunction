scoreboard players set #dynamic bs.config 1
scoreboard players set #round_time bs.config 1800
tellraw @a {"text":"Dificultad: DINAMICA (90s, objetivos por bioma)","color":"light_purple"}
function blockshuffle:menu
