title @s title {"text":"Ronda dinamica","color":"light_purple"}
function blockshuffle:dynamic_show
