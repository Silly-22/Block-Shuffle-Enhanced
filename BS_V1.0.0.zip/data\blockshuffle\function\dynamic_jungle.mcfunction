execute store result score @s bs.rand run random value 7..9
scoreboard players operation @s bs.target = @s bs.rand
