tellraw @a [{"text":"¡Se acabó! Nadie sobrevivió.","color":"red"}]
scoreboard players set #game bs.status 0
bossbar set blockshuffle:timer visible false
execute as @a run function blockshuffle:menu
