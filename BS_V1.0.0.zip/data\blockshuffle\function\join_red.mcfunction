tag @s remove bs_team_blue
tag @s add bs_team_red
team join bs_rojo @s
tellraw @s {"text":"Te uniste al Equipo Rojo.","color":"red"}
