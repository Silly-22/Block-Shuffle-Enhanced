scoreboard players set @s bs.target 0
execute if biome ~ ~ ~ minecraft:desert run function blockshuffle:dynamic_desert
execute if biome ~ ~ ~ minecraft:badlands run function blockshuffle:dynamic_desert
execute if biome ~ ~ ~ minecraft:forest run function blockshuffle:dynamic_forest
execute if biome ~ ~ ~ minecraft:birch_forest run function blockshuffle:dynamic_forest
execute if biome ~ ~ ~ minecraft:dark_forest run function blockshuffle:dynamic_forest
execute if biome ~ ~ ~ minecraft:jungle run function blockshuffle:dynamic_jungle
execute if biome ~ ~ ~ minecraft:bamboo_jungle run function blockshuffle:dynamic_jungle
execute if biome ~ ~ ~ minecraft:snowy_plains run function blockshuffle:dynamic_snow
execute if biome ~ ~ ~ minecraft:snowy_taiga run function blockshuffle:dynamic_snow
execute if biome ~ ~ ~ minecraft:taiga run function blockshuffle:dynamic_snow
execute if biome ~ ~ ~ minecraft:nether_wastes run function blockshuffle:dynamic_nether
execute if biome ~ ~ ~ minecraft:crimson_forest run function blockshuffle:dynamic_nether
execute if biome ~ ~ ~ minecraft:warped_forest run function blockshuffle:dynamic_nether
execute unless score @s bs.target matches 1.. run function blockshuffle:dynamic_default
