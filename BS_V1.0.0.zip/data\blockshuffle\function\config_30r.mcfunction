scoreboard players set #total_rounds bs.config 30
tellraw @a [{"text":"Rondas configuradas: 30","color":"red"}]
function blockshuffle:menu
